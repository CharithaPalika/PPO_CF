# Manual secondary-goal induction: PPO-GAE only

## Production protocol: tune PPO first, then analyse secondary steering

Use the two launch scripts below for the final study. They use the new online
W&B project **ppo-manual-secondary-goal**, so these runs cannot mix with E1,
E2, or deleted W&B run IDs.

**Phase 1 — 10 ordinary PPO-GAE runs, same seed 0.** The candidates vary only
one interpretable PPO setting (learning rate, entropy coefficient, GAE lambda,
clip coefficient, or rollout length). They do not use the blue-token signal.
After all ten complete, a dependent selector writes
runs/manual_secondary_two_phase/best_ppo_params.json. Selection is fixed
before inspecting results: highest final validation goal success, then final
validation primary return, then the lower candidate index. Final test episodes
are never used for tuning.

```bash
./submit_manual_secondary_phase1.sh
```

**Phase 2 — fresh matched analysis.** The selected PPO settings are used
unchanged for 5 seeds of normal PPO and 5 seeds at each manual beta
0.25, 0.75, 1.5: **5 + 15 = 20 runs**. These are fresh runs, not fine-tuned
copies of phase 1. Launch this only once the phase-1 selector job has completed:

```bash
./submit_manual_secondary_phase2.sh
```

Each launch uses a 10-element Slurm array throttled as 0-9%10. In phase 2,
each array element owns two fixed sequential runs, so there are at most **10
concurrent jobs** and **10 submitted worker jobs** (plus no persistent
orchestrator). Phase 1 has 10 workers plus one short selector. Both are below
the account limits of 16 concurrent and 32 submitted jobs. Re-running either
script is safe: completed run directories resume/skip through the trainer's
existing completion guard.

The phase-2 output is runs/manual_secondary_two_phase/analysis/. After all
jobs finish:

```bash
python -m manual_steering.experiment --phase plot \
  --output runs/manual_secondary_two_phase/analysis
```

The resulting plots show the primary return/success and token/joint success
for all four arms beta = 0, 0.25, 0.75, 1.5.

## What is compared

Two methods, not a new E2/E3 rerun:

1. **PPO continuation**: beta = 0.
2. **Manual actor-advantage steering**: beta = 0.25, 0.75, 1.5, 3.0.

Five primary pretraining seeds, followed by five matched copies of each primary
checkpoint: **5 pretraining + 25 fine-tuning runs**. Every run has
`ppo.pg_mode: gae`. The grouping fields are `manual.method` and `manual.beta`;
`env.env_id` and `ppo.pg_mode` remain explicit non-null W&B config fields.

This is a demonstration of controllable behaviour induction, not evidence that
the method is better than reward shaping or that primary performance is protected.

## Environment and cost to the primary task

`MiniGrid-DetourPickup-8x8-v0` is a NEW custom environment included here, not a
built-in MiniGrid task. Each episode has a green primary goal and an optional
blue floor tile. Entering the tile automatically collects it and removes it.
It gives **zero environment reward** and never ends the episode.

`layout_seeds: null` is fixed by the experiment launcher. Each reset generates
new randomized geometry, mirror/rotation, detour length, and starting direction.
A null seed pool does not mean every generated map is unique: this is a finite
procedural family. There is no fixed training pool and no shuffled-signal arm.

The normal MiniGrid terminal reward is retained:
\[
r_{\mathrm{goal}} = 1 - 0.9\,t/64 .
\]
All other primary rewards are zero. Both methods have the same 64-action budget.
The short, medium and long detours add respectively 6, 12–14 and 16–18 optimal
actions in the current generator. Both primary-only and joint routes are checked
for feasibility. Neither beta nor the method label is passed to the environment.

The clock is part of the task: reaching the deadline is a terminal failure, not
an external truncation that should be bootstrapped through. Both policies see the
same full grid plus a fourth, constant image channel for remaining time.
They receive no BFS distances, token coordinates, recommended actions, or beta.
The token's presence/absence is visible in the ordinary grid.

## Exact intervention

Primary GAE and its value targets are computed by the existing PPO code, using
only the unmodified primary reward. Primary advantages are batch-normalized.

Let d(s) be the minimum number of left/right/forward actions needed to enter the
blue tile from pose (x, y, direction), with the terminal green goal treated as
impassable when planning a token route. This is a hand-coded geometry heuristic,
not a learned critic, counterfactual return, or simulator branch rollout.

The manual score is zero after collection, +1 on the collection transition, and
otherwise `(d_before - d_after) / 5`. Five is a FIXED scale: a forward action can
be undone in at most five primitive actions. Thus scores are bounded and ordinary
progress sums to zero around closed pre-token loops. We do not clip negative
progress to -1 before scaling: that could reward repeatedly walking away and back.

The sampled-action actor advantage is:
\[
A^{actor}_t = \operatorname{normalize}(A^{primary,GAE}_t) + \beta B_t.
\]

The manual score is detached and added AFTER primary normalization; the combined
advantage is not re-normalized. It is not batch-centered or divided by a moving
standard deviation. This corrects the earlier plan's normalization leakage and
keeps zero scores exactly zero. Beta = 0 is an exact identity at this hook.

Only the actor loss changes. GAE returns, the primary reward, and the primary
value-loss formula do not. Separate actor/critic encoders and separate gradient
clipping prevent direct cross-head gradient effects. Of course the critic will
eventually see different trajectories as the actor changes.

## Install and verify FIRST

Use your existing project virtual environment; do not install into a shared lab
environment. All runtime packages are already listed in `requirements.txt`.
For the notebook, also install `jupyterlab` if needed.

Run from the repository root:
```bash
python -m pip install -r requirements.txt
python -m manual_steering.verify --full
```

Do not start the full sweep until it prints `FULL VERIFICATION PASSED`.
The verifier writes only temporary test artifacts and disables real W&B logging.

Checks include 1,000 valid layouts, orientation-aware distances, zero post-token
perturbation, no positive turning loops, actual MiniGrid transitions/reward,
terminal info surviving autoreset, beta-zero PPO equivalence, unchanged critic
updates on the same rollout, interrupt/resume equivalence, W&B config grouping,
existing E0–E3 config resolution, and all four plot outputs.

Without torch/MiniGrid, you may run:
```bash
python -m manual_steering.verify --logic-only
```
That is explicitly **NOT** a substitute for the full verifier.

## Local notebook

Open `notebooks/05_manual_secondary_goal.ipynb`.
Run the verification and environment preview cells first. The training cell is
guarded by `RUN_TRAINING = False`; change it to True to run the sweep.

## Full CLI experiment

```bash
python -m manual_steering.experiment \
  --output runs/manual_secondary_v1 \
  --seeds 0 1 2 3 4 --betas 0 0.25 0.75 1.5 3.0 \
  --pretrain-steps 500000 --finetune-steps 200000 \
  --eval-episodes 200 --test-episodes 500 \
  --workers 1 --threads 2
```

Each requested budget is rounded UP to complete 16 x 64 rollouts:
500,736 primary steps and 200,704 fine-tuning steps. Requested settings are
recorded in `sweep.json`; actual counts are in every run's config and results.

For five workers, request at least ten CPU threads and set `--workers 5 --threads 2`.
Each worker runs one seed's primary training and beta sweep. No CF queries are run.

Pretraining must reach 90% stochastic validation success before that seed's
fine-tuning starts. A failure pauses that seed; inspect its learning curve and
use a new output directory for a revised pretraining budget. Do not silently
drop failed seeds or pick only convenient checkpoints.

To separate stages, pass `--phase pretrain` and then `--phase finetune`,
keeping every other sweep argument unchanged.

## Resume and output protection

Repeat the SAME command and output path. Completed runs are skipped; interrupted
runs resume from the last saved update boundary, including weights, optimizer,
environment states, layout/action RNGs and evaluation history. At most one logging
interval of uncheckpointed updates is repeated. Do not run two workers for the
same seed/output simultaneously.

Changed experiment settings are rejected for an existing output directory.
Use a new output name to change budgets, betas, or seeds. Old results are not
deleted. Only load trusted checkpoint files produced by this project.

## Optional online W&B

Before launching:
```bash
export PPO_CF_WANDB=1
export WANDB_MODE=online
export PPO_CF_WANDB_PROJECT=ppo-cf
export PPO_CF_WANDB_RUN_NAMESPACE=manual_secondary_v1
export PPO_CF_WANDB_RESUME=allow
```

Keep the namespace fixed during a sweep. If runs were deliberately deleted from
W&B, use a NEW namespace for a new sweep. Local CSVs remain the source of truth.
Logging failure does not silently change the training algorithm.

## Upload and use on NUS

From INSIDE the unpacked PPO_CF directory on your local computer:
```bash
scp -J aniket@stujump.comp.nus.edu.sg -r ./* \
  aniket@xlogin.comp.nus.edu.sg:~/ppo_cf/
```

On xlogin, obtain a compute allocation before testing or training; do not run PPO
on the shared login node. For example, for verification:
```bash
cd ~/ppo_cf
srun --partition=normal --cpus-per-task=4 --mem=8G --time=00:30:00 --pty bash
source .venv/bin/activate
python -m manual_steering.verify --full
```

After verification passes, run the CLI/notebook on a suitably sized compute
allocation. The new experiment does not modify the E1/E2/E3 Slurm launchers.
Automatic new Slurm submission is intentionally not included in this package;
the PyTorch/MiniGrid verifier must pass on the target environment first.

## Evaluation and plots

Validation: 200 common seeded episodes per checkpoint, including BEFORE any
fine-tuning. Final test: 500 episodes from a separate seed bank.
Policy actions are sampled with independent per-episode RNGs, identically seeded
across beta arms. Evaluation never consumes the training action RNG and never
applies a hand-coded action override.

Fresh evaluation seeds are NOT a guarantee of unseen geometry in a finite layout
family; the saved layout hashes make overlaps auditable. Do not call this a
strict held-out-geometry generalization benchmark.

Rebuild figures anytime:
```bash
python -m manual_steering.experiment --phase plot --output runs/manual_secondary_v1
```

The plotting code uses only seeds with all requested beta arms completed, warns
about partial sweeps, and writes the sample counts. It does not choose a best
seed or impose a trend.

| File, under figures/ | Content |
|---|---|
| priority_response.png / .pdf | Primary return, goal success, token collection and joint success vs beta |
| primary_cost_secondary_gain.png / .pdf | Paired token-collection gain vs signed primary-return cost |
| learning_curves.png / .pdf | The same four metrics vs fine-tuning steps |
| detour_cost_buckets.png / .pdf | Responses separated by short/medium/long detours |

Under tables/: per_seed_metrics.csv, paired_tradeoffs.csv, summary.csv, and
per_seed_learning_curves.csv. Report seed-bootstrap 95% intervals; one-seed
checks have no meaningful seed-level interval.

Primary cost is J(beta=0 continuation) - J(beta), NOT cost relative to a frozen
pretraining checkpoint. Secondary gain is P_token(beta) - P_token(beta=0).
Negative cost (a primary improvement) is retained, not clamped to zero.

## Interpretation limits

Increasing beta is expected to encourage token collection, but neither monotonic
behaviour nor a primary-performance loss is guaranteed. A policy may collect the
token more while retaining high primary success, with only a slower goal reward.
Report the observed trade-off, failures, and confidence intervals honestly.

This code demonstrates an actor-only manual intervention. Its relationship to
auxiliary rewards/policy shaping still needs to be discussed in a paper; leaving
the critic primary-only is not by itself a novelty or safety guarantee.

## Implementation references

- [MiniGrid custom-environment tutorial](https://minigrid.farama.org/content/create_env_tutorial/)
- [Gymnasium: handling time limits](https://gymnasium.farama.org/tutorials/gymnasium_basics/handling_time_limits/)
