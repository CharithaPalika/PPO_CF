"""MiniGrid detour task with a reward-free, automatically collected blue tile.

Both methods see the same grid and remaining-time channel. The episode deadline
is part of this finite-horizon task (a TRUE terminal), not an external truncation.
"""
from __future__ import annotations

import copy
import gymnasium as gym
import numpy as np
from minigrid.core.grid import Grid
from minigrid.core.mission import MissionSpace
from minigrid.core.world_object import Floor, Goal, Wall
from minigrid.minigrid_env import MiniGridEnv

from manual_steering.geometry import (Layout, distances, generate, generate_two_route,
                                      manual_signal, path)

ENV_ID = "MiniGrid-DetourPickup-8x8-v0"
TWO_ROUTE_ENV_ID = "MiniGrid-TwoRouteToken-8x8-v0"


class DetourPickupEnv(MiniGridEnv):
    def __init__(self, max_steps=64, goal_time_penalty=.9, **kwargs):
        if int(max_steps) < 32:
            raise ValueError("Use max_steps >= 32 so all designed joint routes are feasible")
        self.token_collected = False
        self.last_step_info = {}
        self.goal_time_penalty = float(goal_time_penalty)
        if not 0.0 <= self.goal_time_penalty <= 1.0:
            raise ValueError("goal_time_penalty must lie in [0, 1]")
        super().__init__(mission_space=MissionSpace(mission_func=self._mission),
                         grid_size=8, max_steps=int(max_steps),
                         see_through_walls=True, **kwargs)

    @staticmethod
    def _mission():
        return "reach the green goal"

    def _gen_grid(self, width, height):
        layout_seed = int(self.np_random.integers(0, 2**31))
        self.layout = generate(layout_seed)
        self.grid = Grid(width, height)
        for x in range(width):
            for y in range(height):
                if (x, y) not in self.layout.cells:
                    self.grid.set(x, y, Wall())
        self.put_obj(Goal(), *self.layout.goal)
        # A blue Floor auto-collects on entry; no extra PICKUP skill is required.
        self.put_obj(Floor("blue"), *self.layout.token)
        self.agent_pos = self.layout.start
        self.agent_dir = self.layout.direction
        self.token_collected = False
        self.token_step = -1
        self.mission = self._mission()
        self._distances = distances(self.layout.cells, self.layout.token,
                                    blocked=(self.layout.goal,))

    def _pose(self):
        return int(self.agent_pos[0]), int(self.agent_pos[1]), int(self.agent_dir)

    def step(self, action):
        active = not self.token_collected
        before = self._distances.get(self._pose(), 0)
        _, reward, terminated, truncated, info = super().step(action)
        collected_now = active and tuple(self.agent_pos) == self.layout.token
        if collected_now:
            self.token_collected = True
            self.token_step = self.step_count
            self.grid.set(*self.layout.token, None)
        # A deadline is a finite-horizon failure; never bootstrap beyond it.
        goal_success = tuple(self.agent_pos) == self.layout.goal
        if goal_success:
            # MiniGrid's default goal reward hard-codes a 0.9 time penalty.
            # Phase 4b exposes that coefficient as the single experimental knob.
            reward = 1.0 - self.goal_time_penalty * self.step_count / self.max_steps
        timeout = self.step_count >= self.max_steps and not goal_success
        terminated = bool(terminated or truncated)
        truncated = False
        after = self._distances.get(self._pose(), before)
        signal = manual_signal(active, collected_now, before, after)
        info = {
            **info, "manual_signal": signal, "manual_active": active,
            "token_collected": self.token_collected, "token_step": self.token_step,
            "primary_success": bool(goal_success),
            "joint_success": bool(goal_success and self.token_collected),
            "goal_time_penalty": self.goal_time_penalty,
            "timeout": bool(timeout), "detour_bucket": self.layout.bucket,
            "direct_steps": self.direct_steps, "joint_optimal_steps": self.joint_steps,
            "detour_extra_steps": self.joint_steps - self.direct_steps,
            "layout_hash": self.layout.fingerprint,
        }
        self.last_step_info = info.copy()
        # Regenerate after removing the token so observations show acquisition.
        return self.gen_obs(), float(reward), terminated, truncated, info

    def state_dict(self):
        return {
            "grid": self.grid.encode(), "layout": copy.deepcopy(self.layout),
            "agent_pos": tuple(self.agent_pos), "agent_dir": self.agent_dir,
            "step_count": self.step_count, "token_collected": self.token_collected,
            "token_step": self.token_step, "direct_steps": self.direct_steps,
            "joint_steps": self.joint_steps, "last_step_info": self.last_step_info.copy(),
            "rng": copy.deepcopy(self.np_random.bit_generator.state),
        }

    def load_state_dict(self, state):
        self.grid, _ = Grid.decode(state["grid"])
        for key in ("layout", "agent_pos", "agent_dir", "step_count", "token_collected",
                    "token_step", "direct_steps", "joint_steps", "last_step_info"):
            setattr(self, key, copy.deepcopy(state[key]))
        self.carrying = None
        self.mission = self._mission()
        self.np_random.bit_generator.state = copy.deepcopy(state["rng"])
        self._distances = distances(self.layout.cells, self.layout.token,
                                    blocked=(self.layout.goal,))


class TwoRouteTokenEnv(DetourPickupEnv):
    """Phase-5 route-choice task with a green token on the longer corridor.

    Every nonterminal transition receives ``-kappa / horizon`` and entering
    the goal receives ``1-kappa / horizon``. Thus a successful T-step episode
    has exactly primary return ``1-kappa*T/horizon`` in both experiment arms.
    The token itself has zero environment reward.
    """
    def __init__(self, token_bonus_ratio=0.0, **kwargs):
        self.token_bonus_ratio = float(token_bonus_ratio)
        if self.token_bonus_ratio < 0:
            raise ValueError("token_bonus_ratio must be non-negative")
        super().__init__(**kwargs)

    def _gen_grid(self, width, height):
        layout_seed = int(self.np_random.integers(0, 2**31))
        self.layout = generate_two_route(layout_seed)
        self.grid = Grid(width, height)
        for x in range(width):
            for y in range(height):
                if (x, y) not in self.layout.cells:
                    self.grid.set(x, y, Wall())
        self.put_obj(Goal(), *self.layout.goal)
        self.put_obj(Floor("green"), *self.layout.token)
        self.agent_pos, self.agent_dir = self.layout.start, self.layout.direction
        self.token_collected, self.token_step = False, -1
        self.route_choice = "uncommitted"
        self.mission = self._mission()
        self._distances = distances(self.layout.cells, self.layout.token,
                                    blocked=(self.layout.goal,))
        self.direct_steps, self.joint_steps = len(path(self.layout)), len(path(self.layout, require_token=True))
        if self.joint_steps >= self.max_steps:
            raise ValueError("Episode budget does not admit this token-plus-goal route")

    def step(self, action):
        active = not self.token_collected
        before = self._distances.get(self._pose(), 0)
        _, _, terminated, truncated, info = MiniGridEnv.step(self, action)
        collected_now = active and tuple(self.agent_pos) == self.layout.token
        if collected_now:
            self.token_collected, self.token_step = True, self.step_count
            self.grid.set(*self.layout.token, None)
        if self.route_choice == "uncommitted":
            pos = tuple(self.agent_pos)
            if pos == self.layout.short_branch:
                self.route_choice = "short"
            elif pos == self.layout.long_branch:
                self.route_choice = "long"
        goal_success = tuple(self.agent_pos) == self.layout.goal
        step_cost = self.goal_time_penalty / self.max_steps
        # This is an external task reward, not an advantage modification.
        # lambda=1 pays exactly the additional undiscounted primary cost of
        # the token route for this realized orientation/layout.
        token_bonus = (self.token_bonus_ratio * self.goal_time_penalty
                       * (self.joint_steps - self.direct_steps) / self.max_steps
                       if collected_now else 0.0)
        reward = (1.0 - step_cost if goal_success else -step_cost) + token_bonus
        timeout = self.step_count >= self.max_steps and not goal_success
        after = self._distances.get(self._pose(), before)
        signal = manual_signal(active, collected_now, before, after)
        info = {
            **info, "manual_signal": signal, "manual_active": active,
            "token_collected": self.token_collected, "token_step": self.token_step,
            "primary_success": bool(goal_success),
            "joint_success": bool(goal_success and self.token_collected),
            "goal_time_penalty": self.goal_time_penalty, "step_cost": step_cost,
            "token_bonus_ratio": self.token_bonus_ratio, "token_bonus": token_bonus,
            "timeout": bool(timeout), "detour_bucket": self.layout.bucket,
            "direct_steps": self.direct_steps, "joint_optimal_steps": self.joint_steps,
            "detour_extra_steps": self.joint_steps - self.direct_steps,
            "route_choice": self.route_choice,
            "long_route_chosen": bool(self.route_choice == "long"),
            "layout_hash": self.layout.fingerprint,
        }
        self.last_step_info = info.copy()
        return self.gen_obs(), float(reward), bool(terminated or truncated), False, info

    def state_dict(self):
        state = super().state_dict()
        state["route_choice"] = self.route_choice
        return state

    def load_state_dict(self, state):
        super().load_state_dict(state)
        self.route_choice = state.get("route_choice", "uncommitted")


class RemainingTimeWrapper(gym.ObservationWrapper):
    """Ordinary, shared clock information, not secondary-goal advice."""
    def __init__(self, env):
        super().__init__(env)
        shape = (*env.observation_space.shape[:2], 4)
        self.observation_space = gym.spaces.Box(0, 255, shape=shape, dtype=np.float32)

    def observation(self, observation):
        image = np.asarray(observation, dtype=np.float32)
        remaining = max(0.0, 1.0 - self.unwrapped.step_count / self.unwrapped.max_steps)
        clock = np.full((*image.shape[:2], 1), remaining, dtype=np.float32)
        return np.concatenate((image, clock), axis=-1)


def register():
    if ENV_ID not in gym.envs.registry:
        gym.register(ENV_ID, entry_point="manual_steering.environment:DetourPickupEnv")
    if TWO_ROUTE_ENV_ID not in gym.envs.registry:
        gym.register(TWO_ROUTE_ENV_ID, entry_point="manual_steering.environment:TwoRouteTokenEnv")
