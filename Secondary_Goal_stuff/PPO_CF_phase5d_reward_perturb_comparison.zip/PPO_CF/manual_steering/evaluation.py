"""Matched evaluation seeds, independent action RNGs, and no steering at inference."""
from __future__ import annotations
import numpy as np
import torch
from envs.env_pool import make_env


@torch.no_grad()
def evaluate(model, scaler, cfg, episodes=200, seed_base=9_000_000, greedy=False):
    if episodes < 1:
        raise ValueError("Evaluation requires at least one episode")
    was_training = model.training
    model.eval()
    device = next(model.parameters()).device
    env_kwargs = {"fully_observable": True}
    if cfg.env.env_id in ("MiniGrid-DetourPickup-8x8-v0", "MiniGrid-TwoRouteToken-8x8-v0"):
        env_kwargs["goal_time_penalty"] = cfg.env.goal_time_penalty
    if cfg.env.env_id == "MiniGrid-TwoRouteToken-8x8-v0":
        env_kwargs["token_bonus_ratio"] = cfg.env.token_bonus_ratio
    envs = [make_env(cfg.env.env_id, cfg.env.max_episode_steps, **env_kwargs)
            for _ in range(min(16, episodes))]
    rows = []
    try:
        for start in range(0, episodes, len(envs)):
            count = min(len(envs), episodes - start)
            obs, totals, bonuses, lengths, rngs = [], [0.] * count, [0.] * count, [0] * count, []
            for i in range(count):
                ep_seed = seed_base + start + i
                # Training with a fixed layout must be assessed on that same
                # MDP.  Random-layout training keeps the prior held-out,
                # fresh-layout evaluation distribution.
                fixed_layouts = cfg.env.layout_seeds
                layout_seed = (int(fixed_layouts[(start + i) % len(fixed_layouts)])
                               if fixed_layouts is not None else ep_seed)
                o, _ = envs[i].reset(seed=layout_seed)
                obs.append(np.asarray(o).reshape(-1))
                rngs.append(np.random.default_rng(ep_seed + 50_000_000))
            active = list(range(count))
            while active:
                x = torch.as_tensor(scaler(np.stack([obs[i] for i in active])),
                                    dtype=torch.float32, device=device)
                probabilities = model.action_probs(x).cpu().numpy()
                remaining = []
                for j, i in enumerate(active):
                    if greedy:
                        action = int(probabilities[j].argmax())
                    else:
                        # Common uniforms for paired betas; no training RNG is consumed.
                        action = min(int(np.searchsorted(np.cumsum(probabilities[j]),
                                                         rngs[i].random())), len(probabilities[j]) - 1)
                    o, reward, terminated, truncated, info = envs[i].step(action)
                    totals[i] += float(reward)
                    bonuses[i] += float(info.get("token_bonus", 0.0))
                    lengths[i] += 1
                    obs[i] = np.asarray(o).reshape(-1)
                    if terminated or truncated:
                        rows.append({
                            "eval_episode": start + i, "eval_seed": seed_base + start + i,
                            "evaluation_policy": "greedy" if greedy else "stochastic",
                            "primary_return": totals[i] - bonuses[i],
                            "environment_return": totals[i], "token_bonus_return": bonuses[i],
                            "goal_success": int(info["primary_success"]),
                            "token_success": int(info["token_collected"]),
                            "joint_success": int(info["joint_success"]),
                            "timeout": int(info["timeout"]), "episode_length": lengths[i],
                            "goal_steps": lengths[i] if info["primary_success"] else float("nan"),
                            "detour_bucket": info["detour_bucket"],
                            "detour_extra_steps": info["detour_extra_steps"],
                            "direct_steps": info["direct_steps"],
                            "route_choice": info.get("route_choice", "not_applicable"),
                            "long_route_chosen": int(info.get("long_route_chosen", False)),
                            "evaluation_layout_mode": "fixed" if cfg.env.layout_seeds is not None else "random",
                            "layout_hash": info["layout_hash"],
                        })
                    else:
                        remaining.append(i)
                active = remaining
    finally:
        for env in envs:
            env.close()
        model.train(was_training)
    return sorted(rows, key=lambda r: r["eval_episode"])


def summarize(rows):
    return {key: float(np.mean([row[key] for row in rows]))
            for key in ("primary_return", "goal_success", "token_success",
                        "joint_success", "timeout", "episode_length", "long_route_chosen")}
