"""CLI: python -m manual_steering.experiment --help."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
import json
import math
import multiprocessing
import os
from pathlib import Path


@dataclass(frozen=True)
class Sweep:
    output: str = "runs/manual_secondary_v1"
    seeds: tuple[int, ...] = (0, 1, 2, 3, 4)
    betas: tuple[float, ...] = (0., 0.25, 0.75, 1.5, 3.)
    pretrain_steps: int = 500_000
    finetune_steps: int = 200_000
    n_envs: int = 16
    n_steps: int = 64
    eval_episodes: int = 200
    test_episodes: int = 500
    min_primary_success: float = 0.90
    threads: int = 2

    def validate(self):
        if not self.seeds or len(set(self.seeds)) != len(self.seeds) or min(self.seeds) < 0:
            raise ValueError("Provide distinct non-negative seeds")
        if (0. not in self.betas or len(set(self.betas)) != len(self.betas)
                or any(not math.isfinite(b) or b < 0 for b in self.betas)):
            raise ValueError("Betas must be distinct, finite, non-negative and include 0")
        if min(self.pretrain_steps, self.finetune_steps, self.n_envs, self.n_steps,
               self.eval_episodes, self.test_episodes, self.threads) < 1:
            raise ValueError("Budgets, pool sizes, evaluation counts and threads must be positive")
        if self.n_envs * self.n_steps % 4 or not 0 <= self.min_primary_success <= 1:
            raise ValueError("Batch must be divisible by 4; primary threshold must lie in [0,1]")

    def register(self):
        from manual_steering.io import write_json
        self.validate()
        root = Path(self.output)
        root.mkdir(parents=True, exist_ok=True)
        manifest = root / "sweep.json"
        record = json.loads(json.dumps(asdict(self)))
        if manifest.exists() and json.loads(manifest.read_text()) != record:
            raise ValueError("Sweep settings differ from sweep.json; use a NEW output directory")
        if not manifest.exists():
            write_json(manifest, record)
        return root


def beta_tag(beta):
    return "b" + f"{float(beta):g}".replace(".", "p")


def make_run_config(spec, seed, beta, pretrain):
    from config import make_config
    root = Path(spec.output).resolve()
    batch = spec.n_envs * spec.n_steps
    steps = spec.pretrain_steps if pretrain else spec.finetune_steps
    parent = root / f"seed_{seed}" / "pretrain" / "checkpoints" / "ckpt_100.pt"
    # Round upward to full rollouts and record the requested count in sweep.json.
    return make_config("detourpickup_manual", **{
        "env.n_envs": spec.n_envs, "env.layout_seeds": None,
        "ppo.total_timesteps": math.ceil(steps / batch) * batch,
        "ppo.n_steps": spec.n_steps, "ppo.n_minibatches": 4,
        "manual.enabled": not pretrain and beta > 0, "manual.beta": float(beta),
        "run.seeds": (seed,), "run.init_from": None if pretrain else str(parent),
        "run.run_name": f"{root.name}_{'pretrain' if pretrain else beta_tag(beta)}",
    })


def execute_seed(spec, seed, phase="all"):
    import torch
    from manual_steering.trainer import ManualTrainer
    torch.set_num_threads(spec.threads)
    root = Path(spec.output).resolve() / f"seed_{seed}"
    primary_dir = root / "pretrain"

    def run(beta, pretrain):
        cfg = make_run_config(spec, seed, beta, pretrain)
        out = primary_dir if pretrain else root / "finetune" / beta_tag(beta)
        os.environ["PPO_CF_WANDB_GROUP"] = f"{Path(spec.output).name}_{'pretrain' if pretrain else 'finetune'}"
        os.environ["PPO_CF_WANDB_JOB_TYPE"] = "manual" if cfg.manual.enabled else "ppo"
        os.environ["PPO_CF_WANDB_TAGS"] = f"manual_secondary,{cfg.env.env_id},beta-{beta:g}"
        os.environ.setdefault("PPO_CF_WANDB_RUN_NAMESPACE", "manual_secondary_v1")
        os.environ.setdefault("PPO_CF_WANDB_RESUME", "allow")
        print(cfg.summary(), flush=True)
        trainer = ManualTrainer(cfg, seed, out, spec.eval_episodes, spec.test_episodes)
        return trainer.train()

    if phase in ("all", "pretrain"):
        primary = run(0., True)
    else:
        done = primary_dir / "completed.json"
        if not done.exists():
            raise FileNotFoundError(f"Primary training is incomplete: {primary_dir}")
        primary = json.loads(done.read_text())
    if phase == "pretrain":
        return primary
    rate = primary["validation"]["goal_success"]
    if rate < spec.min_primary_success:
        raise RuntimeError(
            f"Seed {seed}: primary validation success {rate:.3f} < "
            f"{spec.min_primary_success:.3f}. Fine-tuning NOT launched. "
            "Inspect the primary learning curve; use a new output directory for a longer "
            "pretraining budget. Do not lower the gate to select convenient results.")
    return [run(beta, False) for beta in sorted(spec.betas)]


def run_sweep(spec, workers=1, phase="all", seed_index=None):
    spec.register()
    seeds = list(spec.seeds)
    if seed_index is not None:
        if not 0 <= seed_index < len(seeds):
            raise ValueError("seed-index is outside the declared seed list")
        seeds = [seeds[seed_index]]
    if workers < 1:
        raise ValueError("workers must be positive")
    if workers == 1:
        result = [execute_seed(spec, seed, phase) for seed in seeds]
    else:
        # One complete pretrain+beta sequence per worker; independent run paths.
        with ProcessPoolExecutor(max_workers=min(workers, len(seeds)),
                                 mp_context=multiprocessing.get_context("spawn")) as pool:
            futures = [pool.submit(execute_seed, spec, seed, phase) for seed in seeds]
            result = [future.result() for future in futures]
    if phase != "pretrain":
        from manual_steering.plotting import plot_results
        plot_results(spec.output)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="runs/manual_secondary_v1")
    parser.add_argument("--phase", choices=("all", "pretrain", "finetune", "plot"), default="all")
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    parser.add_argument("--betas", nargs="+", type=float, default=[0, .25, .75, 1.5, 3.])
    parser.add_argument("--pretrain-steps", type=int, default=500_000)
    parser.add_argument("--finetune-steps", type=int, default=200_000)
    parser.add_argument("--n-envs", type=int, default=16)
    parser.add_argument("--n-steps", type=int, default=64)
    parser.add_argument("--eval-episodes", type=int, default=200)
    parser.add_argument("--test-episodes", type=int, default=500)
    parser.add_argument("--min-primary-success", type=float, default=.9)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--seed-index", type=int, default=None,
                        help="Optional one-seed worker; keep the full --seeds list unchanged")
    args = parser.parse_args()
    if args.phase == "plot":
        from manual_steering.plotting import plot_results
        plot_results(args.output)
        return
    spec = Sweep(output=args.output, seeds=tuple(args.seeds), betas=tuple(args.betas),
                 pretrain_steps=args.pretrain_steps, finetune_steps=args.finetune_steps,
                 n_envs=args.n_envs, n_steps=args.n_steps,
                 eval_episodes=args.eval_episodes, test_episodes=args.test_episodes,
                 min_primary_success=args.min_primary_success, threads=args.threads)
    run_sweep(spec, args.workers, args.phase, args.seed_index)


if __name__ == "__main__":
    main()

