"""Dependency-free layout generator and pose-space distances.

Distances count left/right/forward actions, not just grid cells. This gives a
useful signal for turning and handles randomized initial orientations correctly.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import hashlib
import random

DIRECTIONS = ((1, 0), (0, 1), (-1, 0), (0, -1))
BUCKETS = ("short", "medium", "long")


@dataclass
class Layout:
    cells: set[tuple[int, int]]
    start: tuple[int, int]
    direction: int
    token: tuple[int, int]
    goal: tuple[int, int]
    bucket: str
    # Present only in the Phase-5 two-route task.  They make the realized
    # route choice auditable without exposing a route label to the policy.
    fork: tuple[int, int] | None = None
    short_branch: tuple[int, int] | None = None
    long_branch: tuple[int, int] | None = None

    @property
    def fingerprint(self):
        # Geometry/orientation hash, not a claim of unique held-out geometry.
        payload = repr((sorted(self.cells), self.start, self.direction, self.token, self.goal,
                        self.fork, self.short_branch, self.long_branch))
        return hashlib.sha256(payload.encode()).hexdigest()[:16]


def successor(pose, action, cells):
    x, y, direction = pose
    if action in (0, 1):
        return x, y, (direction + (-1 if action == 0 else 1)) % 4
    if action == 2:
        dx, dy = DIRECTIONS[direction]
        if (x + dx, y + dy) in cells:
            return x + dx, y + dy, direction
    return pose


def distances(cells, target, blocked=()):
    """Shortest number of actual actions to ENTER target, for every legal pose."""
    legal = set(cells) - set(blocked)
    if target not in legal:
        raise ValueError("Target is not traversable")
    reverse = {}
    for x, y in legal:
        for direction in range(4):
            pose = (x, y, direction)
            for action in (0, 1, 2):
                nxt = successor(pose, action, legal)
                reverse.setdefault(nxt, []).append(pose)
    result = {(target[0], target[1], d): 0 for d in range(4)}
    queue = deque(result)
    while queue:
        pose = queue.popleft()
        for previous in reverse.get(pose, ()):
            if previous not in result:
                result[previous] = result[pose] + 1
                queue.append(previous)
    return result


def path(layout, require_token=False):
    """Auditing/test planner; never supplies actions or labels to the policy."""
    start = (*layout.start, layout.direction, False)
    queue = deque([start])
    previous = {start: None}
    while queue:
        state = queue.popleft()
        x, y, direction, collected = state
        if (x, y) == layout.goal and (collected or not require_token):
            actions = []
            while previous[state] is not None:
                state, action = previous[state]
                actions.append(action)
            return list(reversed(actions))
        # Entering the primary goal ends the episode, so cannot pass through it.
        if (x, y) == layout.goal:
            continue
        for action in (0, 1, 2):
            nxt = successor((x, y, direction), action, layout.cells)
            node = (*nxt, collected or nxt[:2] == layout.token)
            if node not in previous:
                previous[node] = (state, action)
                queue.append(node)
    raise ValueError("Generated layout has no valid route")


def generate(seed: int, bucket: str | None = None) -> Layout:
    rng = random.Random(int(seed))
    bucket = rng.choice(BUCKETS) if bucket is None else bucket
    if bucket not in BUCKETS:
        raise ValueError(f"Unknown detour bucket: {bucket}")
    main_y = rng.choice((5, 6))
    junction_x = rng.choice((3, 4))
    start = (rng.choice((1, 2)), main_y)
    goal = (6, main_y)
    cells = {(x, main_y) for x in range(start[0], 7)}
    depth = {"short": 1, "medium": 2, "long": 4}[bucket]
    tip_y = main_y - depth
    cells.update((junction_x, y) for y in range(tip_y, main_y))
    lateral = 0 if bucket == "short" else rng.choice((1, 2))
    side = rng.choice((-1, 1))
    tip_x = junction_x + side * lateral
    cells.update((junction_x + side * i, tip_y) for i in range(lateral + 1))
    token = (tip_x, tip_y)
    turns, mirror = rng.randrange(4), rng.choice((False, True))

    def transform(pos):
        x, y = pos
        if mirror:
            x = 7 - x
        for _ in range(turns):
            x, y = 7 - y, x
        return x, y

    layout = Layout({transform(p) for p in cells}, transform(start), rng.randrange(4),
                    transform(token), transform(goal), bucket)
    direct, joint = path(layout), path(layout, require_token=True)
    if len(joint) <= len(direct):
        raise AssertionError("Token route must have positive primary action cost")
    return layout


def generate_two_route(seed: int) -> Layout:
    """A short goal route and a strictly longer, through-going token route.

    The two corridors meet again before the same green goal.  The long route
    is never a dead end: after entering its green Floor token, the natural
    forward progress is still toward the goal.  Rotation, reflection and the
    initial heading vary across episodes, while route topology and cost do not.
    """
    rng = random.Random(int(seed))
    start, fork, rejoin, goal = (1, 5), (3, 5), (5, 5), (6, 5)
    short_branch, long_branch, token = (4, 5), (3, 4), (4, 3)
    cells = {(x, 5) for x in range(1, 7)}
    cells.update({(3, 4), (3, 3), (4, 3), (5, 3), (5, 4)})
    turns, mirror = rng.randrange(4), rng.choice((False, True))

    def transform(pos):
        x, y = pos
        if mirror:
            x = 7 - x
        for _ in range(turns):
            x, y = 7 - y, x
        return x, y

    layout = Layout(
        cells={transform(p) for p in cells}, start=transform(start), direction=rng.randrange(4),
        token=transform(token), goal=transform(goal), bucket="two_route",
        fork=transform(fork), short_branch=transform(short_branch), long_branch=transform(long_branch),
    )
    direct, joint = path(layout), path(layout, require_token=True)
    if len(joint) <= len(direct):
        raise AssertionError("Two-route token path must have positive primary action cost")
    return layout


def manual_signal(active, collected_now, before_distance, after_distance):
    """Fixed scale [-1, 1]; no centering, clipping exploit, or off-mask leakage.

    A legal forward action can be undone in at most five primitive actions
    (turn twice, forward, turn twice). Therefore distance changes lie in [-5,1].
    Scaling by FIVE preserves the telescoping potential on closed loops;
    clipping negative progress to -1 would create artificial positive cycles.
    Token entry gets a one-time +1 rather than the ordinary +1/5 progress.
    """
    if not active:
        return 0.0
    if collected_now:
        return 1.0
    delta = before_distance - after_distance
    if not -5 <= delta <= 1:
        raise ValueError("Distances do not describe one legal MiniGrid action")
    return float(delta / 5)
