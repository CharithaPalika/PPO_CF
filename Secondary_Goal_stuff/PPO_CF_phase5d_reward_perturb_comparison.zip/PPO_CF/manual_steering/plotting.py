"""Seed-level, paired trade-offs. Never imposes a decreasing primary curve."""
from __future__ import annotations
import json
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

METRICS = {"primary_return": "Primary return", "goal_success": "Goal success",
           "token_success": "Blue-token collection", "joint_success": "Goal + token success"}
COLORS = ("#146C94", "#21918C", "#7753A6", "#D68A17", "#C64764", "#677B34")


def mean_ci(values):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if not len(values):
        return float("nan"), float("nan"), float("nan")
    mean = float(values.mean())
    if len(values) < 2:
        return mean, float("nan"), float("nan")  # one seed is not an uncertainty estimate
    rng = np.random.default_rng(1209)
    boot = values[rng.integers(0, len(values), size=(5000, len(values)))].mean(axis=1)
    low, high = np.quantile(boot, [.025, .975])
    return mean, float(low), float(high)


def paired_costs(frame):
    keys = ["seed", "detour_bucket"]
    baseline = frame[frame.beta == 0][keys + list(METRICS)]
    if baseline.empty:
        raise ValueError("No completed beta=0 control: cannot compute paired primary costs")
    merged = frame.merge(baseline, on=keys, suffixes=("", "_control"), validate="many_to_one")
    merged["primary_cost"] = merged.primary_return_control - merged.primary_return
    merged["secondary_gain"] = merged.token_success - merged.token_success_control
    merged["goal_success_cost"] = merged.goal_success_control - merged.goal_success
    return merged


def _save(fig, root, name, subtitle):
    fig.suptitle(subtitle, fontsize=13)
    fig.tight_layout(rect=(0, 0, 1, .94))
    for extension in ("png", "pdf"):
        fig.savefig(root / f"{name}.{extension}", dpi=180, bbox_inches="tight")
    plt.close(fig)


def _series(ax, x, mean, low, high, label, color):
    ax.plot(x, mean, marker="o", markersize=4, label=label, color=color)
    ax.fill_between(x, low, high, color=color, alpha=.14)
    ax.grid(alpha=.18)
    ax.spines[["top", "right"]].set_visible(False)


def plot_results(output, title="Manual advantage steering"):
    root = Path(output)
    evaluations = []
    # Legacy sweep layout is seed_*/finetune/beta/.  The two-phase analysis
    # deliberately starts fresh and stores seed_*/ppo|b*/.  Accept both while
    # never looking at phase-1 tuning candidates.
    patterns = ("seed_*/finetune/*/evaluation.csv", "seed_*/*/evaluation.csv")
    seen = set()
    paths = []
    for pattern in patterns:
        for path in root.glob(pattern):
            if path not in seen:
                seen.add(path)
                paths.append(path)
    for path in sorted(paths):
        done = path.parent / "completed.json"
        if not done.exists():
            warnings.warn(f"Excluding incomplete run: {path.parent}")
            continue
        df = pd.read_csv(path)
        result = json.loads(done.read_text())
        if not np.allclose(df.beta, result["beta"]):
            raise ValueError(f"Mixed beta values in {path}")
        evaluations.append(df)
    if not evaluations:
        raise ValueError("No completed fine-tuning runs. Finish a sweep before plotting.")
    episodes = pd.concat(evaluations, ignore_index=True)
    figs, tables = root / "figures", root / "tables"
    figs.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    test = episodes[episodes.split == "test"]
    if test.empty:
        raise ValueError("Missing final test episodes")
    # Keep the requested number of seeds explicit, including partial sweeps.
    counts = test.groupby("beta").seed.nunique().to_dict()
    expected = json.loads((root / "sweep.json").read_text()) if (root / "sweep.json").exists() else {}
    expected_seeds = set(expected.get("seeds", []))
    expected_betas = set(expected.get("betas", counts))
    complete_seeds = set(test.seed.unique())
    for beta in expected_betas:
        complete_seeds &= set(test[test.beta == beta].seed.unique())
    if not complete_seeds:
        raise ValueError("No seed has all requested betas plus beta=0; cannot make a paired comparison")
    partial = (expected_seeds and complete_seeds != expected_seeds) or any(
        n != len(complete_seeds) for n in counts.values())
    if partial:
        warnings.warn(f"PARTIAL SWEEP: using only matched seeds {sorted(complete_seeds)}; counts={counts}")
    test = test[test.seed.isin(complete_seeds)]
    episodes = episodes[episodes.seed.isin(complete_seeds)]
    metrics = [*METRICS, "timeout", "episode_length", "detour_extra_steps"]
    by_bucket = test.groupby(["seed", "beta", "detour_bucket"])[metrics].mean().reset_index()
    overall = test.groupby(["seed", "beta"])[metrics].mean().reset_index()
    overall["detour_bucket"] = "all"
    seed_metrics = pd.concat([overall, by_bucket], ignore_index=True)
    paired = paired_costs(seed_metrics)
    seed_metrics.to_csv(tables / "per_seed_metrics.csv", index=False)
    paired.to_csv(tables / "paired_tradeoffs.csv", index=False)
    summaries = []
    for (beta, bucket), df in paired.groupby(["beta", "detour_bucket"]):
        for metric in metrics + ["primary_cost", "secondary_gain", "goal_success_cost"]:
            mean, low, high = mean_ci(df[metric])
            summaries.append(dict(beta=beta, detour_bucket=bucket, metric=metric,
                                  mean=mean, ci_low=low, ci_high=high, n_seeds=len(df)))
    summary = pd.DataFrame(summaries)
    summary.to_csv(tables / "summary.csv", index=False)
    suffix = f" | n={len(complete_seeds)} seeds; seed-bootstrap 95% CI"
    if partial:
        suffix += " | PARTIAL SWEEP"
    if len(complete_seeds) == 1:
        suffix = " | ONE-SEED CHECK; no confidence interval"
    overall_summary = summary[summary.detour_bucket == "all"]
    fig, axes = plt.subplots(2, 2, figsize=(10, 7))
    for ax, (metric, label) in zip(axes.flat, METRICS.items()):
        data = overall_summary[overall_summary.metric == metric].sort_values("beta")
        _series(ax, data.beta, data["mean"], data.ci_low, data.ci_high, label, COLORS[0])
        ax.set(xlabel="Secondary priority beta", ylabel=label, ylim=(-.03, 1.03))
    _save(fig, figs, "priority_response", title + " — measured beta response" + suffix)

    fig, ax = plt.subplots(figsize=(7, 5))
    for idx, (beta, df) in enumerate(paired[paired.detour_bucket == "all"].groupby("beta")):
        x, xl, xh = mean_ci(df.primary_cost)
        y, yl, yh = mean_ci(df.secondary_gain)
        xerr = [[x-xl], [xh-x]] if np.isfinite(xl) else None
        yerr = [[y-yl], [yh-y]] if np.isfinite(yl) else None
        ax.errorbar(x, y, xerr=xerr, yerr=yerr, fmt="o", capsize=3,
                    color=COLORS[idx % len(COLORS)], label=f"beta={beta:g}")
    ax.axhline(0, color=".6", lw=.7)
    ax.axvline(0, color=".6", lw=.7)
    ax.set(xlabel="Primary return cost relative to PPO continuation (signed)",
           ylabel="Token collection gain relative to PPO continuation")
    ax.legend()
    ax.grid(alpha=.15)
    _save(fig, figs, "primary_cost_secondary_gain", title + " — paired trade-off" + suffix)

    validation = episodes[episodes.split == "validation"]
    seed_curves = validation.groupby(["seed", "beta", "global_step"])[list(METRICS)].mean().reset_index()
    seed_curves.to_csv(tables / "per_seed_learning_curves.csv", index=False)
    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    for ax, (metric, label) in zip(axes.flat, METRICS.items()):
        for idx, (beta, df) in enumerate(seed_curves.groupby("beta")):
            vals = [(step, *mean_ci(sub[metric])) for step, sub in df.groupby("global_step")]
            arr = np.asarray(vals)
            _series(ax, arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3],
                    f"beta={beta:g}", COLORS[idx % len(COLORS)])
        ax.set(xlabel="Fine-tuning environment steps", ylabel=label, ylim=(-.03, 1.03))
        ax.ticklabel_format(axis="x", style="sci", scilimits=(0, 0))
    axes[0, 0].legend(fontsize=8)
    _save(fig, figs, "learning_curves", title + " — matched validation layouts" + suffix)

    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
    for ax, metric in zip(axes, ("primary_return", "token_success", "joint_success")):
        for idx, bucket in enumerate(("short", "medium", "long")):
            data = summary[(summary.metric == metric) & (summary.detour_bucket == bucket)].sort_values("beta")
            _series(ax, data.beta, data["mean"], data.ci_low, data.ci_high, bucket, COLORS[idx])
        ax.set(xlabel="Secondary priority beta", ylabel=METRICS[metric], ylim=(-.03, 1.03))
    axes[0].legend()
    _save(fig, figs, "detour_cost_buckets", title + " — detour difficulty" + suffix)
    print(f"Plots: {figs}; seed-level tables: {tables}", flush=True)
    return {"figures": figs, "tables": tables, "matched_seeds": sorted(complete_seeds)}


def preview_layouts(output):
    from manual_steering.geometry import BUCKETS, DIRECTIONS, generate, path
    from matplotlib.colors import ListedColormap
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.6))
    for i, (ax, bucket) in enumerate(zip(axes, BUCKETS)):
        layout = generate(42 + i, bucket)
        grid = np.zeros((8, 8))
        for x, y in layout.cells:
            grid[y, x] = 1
        grid[layout.token[1], layout.token[0]] = 2
        grid[layout.goal[1], layout.goal[0]] = 3
        ax.imshow(grid, cmap=ListedColormap(["#343B42", "#F2F4F5", "#3489D0", "#53AD72"]),
                  vmin=0, vmax=3)
        dx, dy = DIRECTIONS[layout.direction]
        ax.arrow(*layout.start, dx * .35, dy * .35, width=.05, head_width=.25, color="#D83F38")
        ax.set(title=f"{bucket.capitalize()} detour\n"
                     f"Primary: {len(path(layout))} actions; joint: {len(path(layout, True))}",
               xticks=[], yticks=[])
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return output
