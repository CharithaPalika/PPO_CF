"""Reuses the repository PPO collection, GAE and clipped update.

Only transform_actor_advantages adds the manual signal. A dedicated lifecycle
adds matched evaluation and resumable experiment state without changing E0-E3.
"""
from __future__ import annotations

import copy
import json
import math
import os
import random
import time
from pathlib import Path

import numpy as np
import torch

from agents.buffer import RolloutBuffer
from agents.ppo import PPOTrainer
from dataio.checkpoint import save_checkpoint
from manual_steering.evaluation import evaluate, summarize
from manual_steering.io import fingerprint, write_csv, write_json

_POOL_FIELDS = ("_obs", "episode_id", "episode_t", "episode_return", "episode_length",
                "episode_subgoal1", "episode_subgoal2", "_next_episode_id", "_layout_cursor")
_DEQUES = ("_ep_returns", "_ep_lengths", "_ep_success", "_ep_subgoal1", "_ep_subgoal2")


class ManualBuffer(RolloutBuffer):
    def __init__(self, pool, *args, **kwargs):
        self.pool = pool
        super().__init__(*args, **kwargs)

    def reset(self):
        super().reset()
        self.manual_signal = np.zeros((self.n_steps, self.n_envs), dtype=np.float32)
        self.manual_active = np.zeros((self.n_steps, self.n_envs), dtype=bool)

    def add(self, **kwargs):
        infos = self.pool.last_infos
        kwargs["manual_signal"] = [i["manual_signal"] for i in infos]
        kwargs["manual_active"] = [i["manual_active"] for i in infos]
        super().add(**kwargs)


class ManualTrainer(PPOTrainer):
    def __init__(self, cfg, seed, out_dir, eval_episodes=200, test_episodes=500, progress=True,
                 phase=None):
        if cfg.ppo.pg_mode != "gae" or cfg.ppo.norm_adv != "batch" or cfg.reward.active:
            raise ValueError("This experiment only supports unshaped, batch-normalized PPO-GAE")
        if (cfg.env.layout_seeds is not None and not cfg.manual.allow_fixed_layouts) or cfg.ppo.share_encoder:
            raise ValueError("Use fresh layouts unless explicitly enabled for a fixed-layout diagnostic; use separate actor/critic encoders")
        self.eval_episodes, self.test_episodes = int(eval_episodes), int(test_episodes)
        # Legacy manual_steering.experiment remains pretrain/fine-tune.  The
        # two-phase study supplies explicit labels so W&B/CSV rows cannot be
        # mistaken for a pretraining continuation.
        self.phase = phase or ("finetune" if cfg.run.init_from else "pretrain")
        if min(self.eval_episodes, self.test_episodes) < 1:
            raise ValueError("Evaluation episode counts must be positive")
        super().__init__(cfg, seed, out_dir=out_dir, progress=progress)
        self.buffer = ManualBuffer(
            self.pool, cfg.ppo.n_steps, cfg.env.n_envs, input_dim=self.input_dim,
            raw_obs_dim=self.raw_obs_dim, sim_state_dim=self.pool.sim_state_dim,
            n_actions=self.pool.n_actions, device=cfg.ppo.device)
        self.scalar_rows, self.eval_rows = [], []
        self.completed_updates = 0
        self.signature = fingerprint({"cfg": cfg.to_dict(), "seed": seed,
                                      "eval": self.eval_episodes, "test": self.test_episodes})
        self._manual_stats = {}
        self.resumed = False

    def transform_actor_advantages(self, advantages):
        beta = self.cfg.manual.beta if self.cfg.manual.enabled else 0.0
        raw = torch.as_tensor(self.buffer.manual_signal.reshape(-1),
                              dtype=advantages.dtype, device=advantages.device)
        active = torch.as_tensor(self.buffer.manual_active.reshape(-1),
                                 device=advantages.device)
        if raw.shape != advantages.shape or not bool(torch.isfinite(raw).all()):
            raise ValueError("Malformed manual perturbation")
        if bool((raw.abs() > 1.000001).any()) or bool((raw[~active] != 0).any()):
            raise ValueError("Manual signal must be bounded and zero after collection")
        payload = (float(beta) * raw).detach()
        self._manual_stats = {
            "manual_beta": float(beta), "manual_active_fraction": float(active.float().mean()),
            "manual_signal_mean": float(raw.mean()), "manual_payload_rms": float(payload.square().mean().sqrt()),
            "manual_sign_flip_fraction": float(((advantages * (advantages + payload)) < 0).float().mean()),
        }
        # Exact beta-zero identity, including the existing PPO normalization rule.
        return advantages if beta == 0 else advantages + payload

    def update(self, *args, **kwargs):
        stats = super().update(*args, **kwargs)
        return {**stats, **self._manual_stats}

    def _evaluate(self, split):
        base = 9_000_000 if split == "validation" else 19_000_000
        count = self.eval_episodes if split == "validation" else self.test_episodes
        rows = evaluate(self.model, self.scaler, self.cfg, count, base)
        for row in rows:
            row.update(seed=self.seed, beta=self.cfg.manual.beta,
                       method="manual" if self.cfg.manual.enabled else "ppo",
                       pre_phase=float(self.cfg.manual.pre_phase),
                       goal_time_penalty=float(self.cfg.env.goal_time_penalty),
                       token_bonus_ratio=float(self.cfg.env.token_bonus_ratio),
                       test_scaler=float(self.cfg.manual.test_scaler),
                       test_method=str(self.cfg.manual.test_method),
                       phase=self.phase,
                       global_step=self.global_step, split=split)
        self.eval_rows.extend(rows)
        write_csv(self.out_dir / "evaluation.csv", self.eval_rows)
        return summarize(rows)

    def _record(self, row):
        self.scalar_rows.append(row)
        write_csv(self.out_dir / "scalars.csv", self.scalar_rows)
        for sink in self.logger.sinks:
            try:
                sink.log(row)
            except Exception as exc:
                print(f"[manual logging] {exc!r}; CSV preserved", flush=True)

    def _snapshot(self):
        state = {
            "signature": self.signature, "model_state_dict": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(), "completed_updates": self.completed_updates,
            "global_step": self.global_step, "envs": [e.unwrapped.state_dict() for e in self.pool.envs],
            "pool": {key: copy.deepcopy(getattr(self.pool, key)) for key in _POOL_FIELDS},
            "layout_rng": copy.deepcopy(self.pool._layout_rng.bit_generator.state),
            "python_rng": random.getstate(), "numpy_rng": np.random.get_state(),
            "torch_rng": torch.get_rng_state(), "cuda_rng": torch.cuda.get_rng_state_all()
            if torch.cuda.is_available() else None,
            "deques": {key: list(getattr(self, key)) for key in _DEQUES},
            "ent_coef": self.ent_coef, "success_ema": self._success_ema,
            "prob_floor": self.model.prob_floor, "episode_log": self.episode_log,
            "first_success_step": self.first_success_step,
            "scalar_rows": self.scalar_rows, "eval_rows": self.eval_rows,
        }
        temp = self.out_dir / "resume.pt.tmp"
        torch.save(state, temp)
        os.replace(temp, self.out_dir / "resume.pt")

    def _resume(self):
        path = self.out_dir / "resume.pt"
        if not path.exists():
            return
        # Only load trusted checkpoints produced by this experiment.
        state = torch.load(path, map_location=self.device, weights_only=False)
        if state["signature"] != self.signature:
            raise ValueError("Resume config changed; select a NEW --output directory")
        self.model.load_state_dict(state["model_state_dict"], strict=True)
        self.optimizer.load_state_dict(state["optimizer"])
        for env, saved in zip(self.pool.envs, state["envs"]):
            env.unwrapped.load_state_dict(saved)
        for key, value in state["pool"].items():
            setattr(self.pool, key, value)
        self.pool._layout_rng.bit_generator.state = state["layout_rng"]
        for key, values in state["deques"].items():
            getattr(self, key).extend(values)
        for key in ("completed_updates", "global_step", "ent_coef", "first_success_step",
                    "episode_log", "scalar_rows", "eval_rows"):
            setattr(self, key, state[key])
        self._success_ema, self.model.prob_floor = state["success_ema"], state["prob_floor"]
        random.setstate(state["python_rng"])
        np.random.set_state(state["numpy_rng"])
        torch.set_rng_state(state["torch_rng"].cpu())
        if state["cuda_rng"] is not None and torch.cuda.is_available():
            torch.cuda.set_rng_state_all([r.cpu() for r in state["cuda_rng"]])
        # Roll CSVs back to the last committed update boundary after interruption.
        write_csv(self.out_dir / "scalars.csv", self.scalar_rows)
        write_csv(self.out_dir / "evaluation.csv", self.eval_rows)
        self.resumed = True
        print(f"[manual] resumed update {self.completed_updates}/{self.n_updates}", flush=True)

    def train(self, stop_after_updates=None):
        """stop_after_updates is a verification aid, not an early-stopping rule."""
        done = self.out_dir / "completed.json"
        if done.exists():
            result = json.loads(done.read_text())
            if result["signature"] != self.signature:
                raise ValueError("Completed run has another config; use a NEW --output directory")
            self.logger.close()
            self.pool.close()
            return result
        cfg_path = self.out_dir / "config.json"
        if cfg_path.exists() and fingerprint(json.loads(cfg_path.read_text())) != fingerprint(self.cfg.to_dict()):
            raise ValueError("Existing config differs; use a NEW --output directory")
        self.cfg.save(cfg_path)
        self.pool.reset()
        self._resume()
        started, step_start = time.monotonic(), self.global_step
        interval = max(1, self.n_updates // 8)
        log_interval = max(1, self.cfg.run.log_every_updates)
        checkpoint_updates = {math.ceil(f * self.n_updates): f
                              for f in self.cfg.run.checkpoint_fractions}
        try:
            if not self.scalar_rows:
                initial = self._evaluate("validation")
                self._record({"update": 0, "global_step": 0, "manual_beta": self.cfg.manual.beta,
                              "reward_lambda": self.cfg.env.token_bonus_ratio,
                              "secondary_weight": (self.cfg.manual.beta if self.cfg.manual.enabled
                                                   else self.cfg.env.token_bonus_ratio),
                              "test_scaler": self.cfg.manual.test_scaler,
                              **{f"eval_{k}": v for k, v in initial.items()}})
                self._snapshot()
            for update in range(self.completed_updates + 1, self.n_updates + 1):
                if self.cfg.ppo.anneal_lr:
                    lr = self.cfg.ppo.learning_rate * (1 - (update - 1) / self.n_updates)
                    for group in self.optimizer.param_groups:
                        group["lr"] = lr
                self.collect_rollout()
                advantages, returns = self.compute_advantages()
                stats = self.update(advantages, returns)
                self._update_schedules(stats["entropy"], update)
                self.completed_updates = update
                evaluation = {}
                if update % interval == 0 or update == self.n_updates:
                    evaluation = self._evaluate("validation")
                if evaluation or update % log_interval == 0 or update == self.n_updates:
                    recent = self.episode_log[-100:]
                    row = {
                        "update": update, "global_step": self.global_step,
                        "mean_return_100": float(np.mean(self._ep_returns)) if self._ep_returns else float("nan"),
                        "success_rate_100": float(np.mean(self._ep_success)) if self._ep_success else 0.,
                        "token_rate_100": float(np.mean([e["token_collected"] for e in recent])) if recent else 0.,
                        "joint_rate_100": float(np.mean([e["joint_success"] for e in recent])) if recent else 0.,
                        "long_route_rate_100": float(np.mean([e.get("long_route_chosen", False) for e in recent])) if recent else 0.,
                        "reward_lambda": self.cfg.env.token_bonus_ratio,
                        "secondary_weight": (self.cfg.manual.beta if self.cfg.manual.enabled
                                             else self.cfg.env.token_bonus_ratio),
                        "test_scaler": self.cfg.manual.test_scaler,
                        "lr": self.optimizer.param_groups[0]["lr"],
                        "sps": (self.global_step - step_start) / max(time.monotonic() - started, 1e-9),
                        **stats, **{f"eval_{k}": v for k, v in evaluation.items()},
                    }
                    self._record(row)
                    self._snapshot()
                    if self.progress:
                        print(f"[manual] seed={self.seed} beta={self.cfg.manual.beta:g} "
                              f"step={self.global_step} goal={row['success_rate_100']:.3f} "
                              f"token={row['token_rate_100']:.3f}", flush=True)
                if update in checkpoint_updates:
                    fraction = checkpoint_updates[update]
                    save_checkpoint(self.out_dir / "checkpoints" / f"ckpt_{round(100*fraction):03d}.pt",
                                    self.model, self.scaler, self.optimizer, self.global_step, fraction)
                if stop_after_updates is not None and update >= stop_after_updates:
                    self._snapshot()
                    return {"paused": True, "global_step": self.global_step}
            # Final test set is separate from the repeated validation layouts.
            test = self._evaluate("test")
            save_checkpoint(self.out_dir / "checkpoints" / "ckpt_100.pt", self.model,
                            self.scaler, self.optimizer, self.global_step, 1.0,
                            extra={"seed": self.seed, "manual_beta": self.cfg.manual.beta})
            write_csv(self.out_dir / "episodes.csv", self.episode_log)
            result = {"signature": self.signature, "global_step": self.global_step,
                      "seed": self.seed, "beta": self.cfg.manual.beta,
                      "checkpoint": str(self.out_dir / "checkpoints" / "ckpt_100.pt"),
                      "test": test, "validation": summarize([r for r in self.eval_rows
                           if r["split"] == "validation" and r["global_step"] == self.global_step])}
            write_json(done, result)
            return result
        finally:
            self.logger.close()
            self.pool.close()
