"""Two-phase manual-secondary study.

Phase 1 runs exactly ten ordinary-PPO candidates on one fixed seed. It chooses
the candidate with highest final validation goal success, breaking exact ties
by validation primary return. Phase 2 then launches fresh, matched runs:
five PPO controls and five runs for each requested non-zero beta.

Phase 3 is a separate checkpoint-continuation study.  It starts every arm
from the selected phase-1 PPO checkpoint, then uses the existing state-gated
manual signal: the added actor advantage is non-zero only before blue has been
entered.  It never selects on final tests.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path

from manual_steering.io import write_json


@dataclass(frozen=True)
class Candidate:
    name: str
    overrides: dict


# A compact, deliberately interpretable PPO sweep around the supplied manual
# task defaults. All candidates remain standard PPO-GAE; no reward shaping,
# counterfactual query, or secondary intervention can enter phase 1.
CANDIDATES = (
    Candidate("reference", {}),
    Candidate("lr_3e-4", {"ppo.learning_rate": 3e-4}),
    Candidate("lr_1e-3", {"ppo.learning_rate": 1e-3}),
    Candidate("entropy_0p003", {"ppo.ent_coef": .003}),
    Candidate("entropy_0p02", {"ppo.ent_coef": .02}),
    Candidate("lr3e-4_entropy0p003", {"ppo.learning_rate": 3e-4, "ppo.ent_coef": .003}),
    Candidate("lr1e-3_entropy0p003", {"ppo.learning_rate": 1e-3, "ppo.ent_coef": .003}),
    Candidate("lambda_0p98", {"ppo.gae_lambda": .98}),
    Candidate("clip_0p1", {"ppo.clip_coef": .1}),
    Candidate("rollout_128", {"ppo.n_steps": 128}),
)

DEFAULT_SEEDS = (0, 1, 2, 3, 4)
DEFAULT_BETAS = (.25, .75, 1.5)
DEFAULT_PHASE3_BETAS = (.25, .75, 1.5, 3.0, 5.0)
DEFAULT_PHASE4A_PRE_PHASES = (.30, .50, .75, 1.00)
DEFAULT_PHASE4A_BETAS = (.25, .75, 1.5, 3.0, 5.0)
DEFAULT_PHASE4A_SEEDS = (0, 1, 2)
DEFAULT_PHASE4B_KAPPAS = (0.0, .3, .6, .9)
DEFAULT_PHASE4B_SEEDS = (0, 1, 2)
DEFAULT_PHASE4B_BETA = 3.0
DEFAULT_PHASE5_BETAS = (.25, .75, 1.5, 3.0, 5.0)
DEFAULT_PHASE5_SEEDS = (0, 1, 2)
DEFAULT_PHASE5_KAPPA = .9
DEFAULT_PHASE5B_BONUS_RATIOS = (.25, .75, 1.5, 3.0, 5.0, 7.0, 13.0)
DEFAULT_PHASE5B_SEEDS = (0, 1, 2)
DEFAULT_PHASE5B_KAPPA = .9
DEFAULT_PHASE5C_BONUS_RATIOS = DEFAULT_PHASE5B_BONUS_RATIOS
DEFAULT_PHASE5C_SEEDS = (0, 1, 2)
DEFAULT_PHASE5C_KAPPA = .9
DEFAULT_PHASE5C_LAYOUT_SEED = 0
DEFAULT_PHASE5D_REWARD_LAMBDAS = (.2, .5, 1.0, 3.0)
DEFAULT_PHASE5D_PERTURB_BETAS = (.5, 2.0, 6.0, 10.0)
DEFAULT_PHASE5D_SEEDS = (0, 1, 2)
DEFAULT_PHASE5D_KAPPA = .9
DEFAULT_PHASE5D_FIXED_LAYOUT_SEED = 0


def _rounded_steps(requested, n_envs, n_steps):
    return math.ceil(int(requested) / (n_envs * n_steps)) * n_envs * n_steps


def _output(path):
    return Path(path).resolve()


def _make_cfg(candidate, seed, total_steps, beta, run_name, init_from=None, pre_phase=0.0,
              experiment_phase="unlabelled", goal_time_penalty=.9,
              env_config="detourpickup_manual", token_bonus_ratio=0.0,
              fixed_layout_seed=None, test_scaler=0.0, test_method="unlabelled",
              test_layout_mode="unlabelled"):
    from config import make_config
    n_steps = int(candidate.overrides.get("ppo.n_steps", 64))
    override = {
        "env.n_envs": 16,
        "env.layout_seeds": None if fixed_layout_seed is None else (int(fixed_layout_seed),),
        "env.goal_time_penalty": float(goal_time_penalty),
        "env.token_bonus_ratio": float(token_bonus_ratio),
        "ppo.total_timesteps": _rounded_steps(total_steps, 16, n_steps),
        "ppo.n_steps": n_steps,
        "ppo.n_minibatches": 4,
        "ppo.pg_mode": "gae",
        "manual.enabled": beta > 0,
        "manual.beta": float(beta),
        "manual.pre_phase": float(pre_phase),
        "manual.phase": str(experiment_phase),
        "manual.allow_fixed_layouts": fixed_layout_seed is not None,
        "manual.test_scaler": float(test_scaler),
        "manual.test_method": str(test_method),
        "manual.test_layout_mode": str(test_layout_mode),
        "run.seeds": (int(seed),),
        "run.init_from": None if init_from is None else str(init_from),
        # Phase 3 is a matched policy continuation, not a continuation of the
        # phase-1 Adam moments from seed 0.  Every arm receives a fresh,
        # identical optimizer state while loading exactly the same model.
        "run.init_load_optimizer": False,
        "run.run_name": run_name,
        **candidate.overrides,
    }
    return make_config(env_config, **override)


def _logger_environment(project, group, job_type, tags):
    # These are process-local inside each Slurm task. The W&B project is
    # intentionally new so this study cannot collide with deleted E2 runs.
    os.environ["PPO_CF_WANDB"] = "1"
    os.environ["WANDB_MODE"] = "online"
    os.environ["PPO_CF_WANDB_PROJECT"] = project
    os.environ["PPO_CF_WANDB_GROUP"] = group
    os.environ["PPO_CF_WANDB_JOB_TYPE"] = job_type
    os.environ["PPO_CF_WANDB_TAGS"] = tags
    os.environ.setdefault("PPO_CF_WANDB_RESUME", "allow")
    os.environ.setdefault("PPO_CF_WANDB_RUN_NAMESPACE", "manual_secondary_two_phase_v1")


def run_tune(output, candidate_index, seed=0, steps=500_000, eval_episodes=200, test_episodes=500,
             project="ppo-manual-secondary-goal"):
    from manual_steering.trainer import ManualTrainer
    if not 0 <= candidate_index < len(CANDIDATES):
        raise ValueError(f"candidate-index must be in [0, {len(CANDIDATES) - 1}]")
    candidate = CANDIDATES[candidate_index]
    root = _output(output)
    out = root / "tuning" / f"candidate_{candidate_index:02d}_{candidate.name}"
    cfg = _make_cfg(candidate, seed, steps, 0., f"manual_tune_{candidate_index:02d}_{candidate.name}")
    _logger_environment(project, "manual_secondary_phase1_tuning", "ppo_tuning",
                        f"manual_secondary,phase1,ppo,candidate-{candidate_index}")
    print(cfg.summary(), flush=True)
    return ManualTrainer(cfg, seed, out, eval_episodes, test_episodes, phase="tuning").train()


def select_best(output):
    root = _output(output)
    records = []
    for index, candidate in enumerate(CANDIDATES):
        out = root / "tuning" / f"candidate_{index:02d}_{candidate.name}"
        done = out / "completed.json"
        if not done.exists():
            raise FileNotFoundError(f"Missing completed tuning run: {done}")
        result = json.loads(done.read_text())
        if result.get("beta") != 0.0 or result.get("seed") != 0:
            raise ValueError(f"Invalid tuning result: {done}")
        val = result["validation"]
        records.append({
            "candidate_index": index, "candidate": candidate.name,
            "overrides": candidate.overrides, "goal_success": float(val["goal_success"]),
            "primary_return": float(val["primary_return"]), "global_step": result["global_step"],
        })
    # Deterministic, predeclared, validation-only selector. Candidate index is
    # a final deterministic tie-breaker, never a visual-curve judgement.
    winner = max(records, key=lambda r: (r["goal_success"], r["primary_return"], -r["candidate_index"]))
    payload = {
        "selection_rule": "max final validation goal_success; then validation primary_return; then lower candidate index",
        "phase1_seed": 0, "candidate_count": len(CANDIDATES), "candidates": records,
        "selected": winner,
    }
    write_json(root / "best_ppo_params.json", payload)
    # Written once by the selector, before the phase-2 array is submitted.
    # Array workers must never concurrently replace a shared manifest.
    write_json(root / "analysis" / "sweep.json", {
        "seeds": list(DEFAULT_SEEDS), "betas": [0., *DEFAULT_BETAS],
        "phase": "fresh_matched_analysis", "selected_candidate": winner["candidate"],
        "selected_overrides": winner["overrides"], "n_runs": 20, "n_chunks": 10,
    })
    return payload


def _load_winner(output):
    path = _output(output) / "best_ppo_params.json"
    if not path.exists():
        raise FileNotFoundError(
            f"{path} is absent. Finish phase 1; its selector job writes this file before phase 2.")
    selected = json.loads(path.read_text()).get("selected")
    if not selected or not 0 <= int(selected["candidate_index"]) < len(CANDIDATES):
        raise ValueError(f"Malformed selected PPO settings: {path}")
    candidate = CANDIDATES[int(selected["candidate_index"])]
    if candidate.overrides != selected["overrides"]:
        raise ValueError("best_ppo_params.json does not match this code's candidate table")
    return candidate


def _selected_checkpoint(output, fraction=1.0):
    """Return the exact phase-1 model selected by validation-only tuning."""
    root = _output(output)
    payload = json.loads((root / "best_ppo_params.json").read_text())
    selected = payload.get("selected")
    if not selected:
        raise ValueError("best_ppo_params.json has no selected candidate")
    index = int(selected["candidate_index"])
    if not 0 <= index < len(CANDIDATES):
        raise ValueError("best_ppo_params.json has an invalid candidate index")
    candidate = CANDIDATES[index]
    if selected.get("candidate") != candidate.name or selected.get("overrides") != candidate.overrides:
        raise ValueError("best_ppo_params.json does not match this code's candidate table")
    if int(payload.get("phase1_seed", -1)) != 0:
        raise ValueError("Phase 3 requires the declared phase-1 seed-0 checkpoint")
    fraction = float(fraction)
    if not 0 < fraction <= 1:
        raise ValueError("checkpoint fraction must lie in (0, 1]")
    checkpoint = (root / "tuning" / f"candidate_{index:02d}_{candidate.name}" /
                  "checkpoints" / f"ckpt_{round(100 * fraction):03d}.pt")
    if not checkpoint.exists():
        raise FileNotFoundError(f"Selected phase-1 checkpoint is missing: {checkpoint}")
    return candidate, checkpoint.resolve()


def _pre_tag(fraction):
    return f"pre-phase-{round(100 * float(fraction)):03d}"


def _checkpoint_tag(fraction):
    return f"checkpoint-{round(100 * float(fraction)):03d}"


def _kappa_tag(kappa):
    return "kappa-" + f"{float(kappa):.1f}".replace(".", "p")


def phase2_units(seeds=DEFAULT_SEEDS, betas=DEFAULT_BETAS):
    if len(set(seeds)) != len(seeds) or any(int(s) < 0 for s in seeds):
        raise ValueError("seeds must be distinct non-negative integers")
    if len(set(betas)) != len(betas) or any(not math.isfinite(b) or b <= 0 for b in betas):
        raise ValueError("betas must be distinct, finite and strictly positive")
    # Four arms per seed for the requested three betas: PPO plus b=.25/.75/1.5.
    return [(int(seed), beta) for seed in seeds for beta in (0., *betas)]


def contiguous_slice(items, index, chunks):
    if not 0 <= index < chunks:
        raise ValueError("chunk-index outside [0, n-chunks)")
    base, rem = divmod(len(items), chunks)
    start = index * base + min(index, rem)
    return items[start:start + base + (index < rem)]


def run_phase2_chunk(output, chunk_index, n_chunks=10, seeds=DEFAULT_SEEDS, betas=DEFAULT_BETAS,
                     steps=500_000, eval_episodes=200, test_episodes=500,
                     project="ppo-manual-secondary-goal"):
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    candidate = _load_winner(root)
    units = phase2_units(tuple(seeds), tuple(betas))
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 10 or len(units) != 20 or len(mine) != 2:
        raise ValueError("This protocol requires exactly 20 runs split into ten two-run chunks")
    analysis = root / "analysis"
    analysis.mkdir(parents=True, exist_ok=True)
    results = []
    for seed, beta in mine:
        arm = "ppo" if beta == 0 else "manual_" + str(beta).replace(".", "p")
        out = analysis / f"seed_{seed}" / arm
        cfg = _make_cfg(candidate, seed, steps, beta, f"manual_analysis_{arm}")
        method = "ppo" if beta == 0 else "manual"
        _logger_environment(project, "manual_secondary_phase2_analysis", method,
                            f"manual_secondary,phase2,{method},beta-{beta:g},candidate-{candidate.name}")
        print(f"[phase2 chunk {chunk_index}/{n_chunks}] seed={seed} beta={beta:g}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="analysis").train())
    return results


def phase3_units(seeds=DEFAULT_SEEDS, betas=DEFAULT_PHASE3_BETAS):
    """Matched PPO-continuation control plus five state-gated steering arms."""
    if len(set(seeds)) != len(seeds) or any(int(s) < 0 for s in seeds):
        raise ValueError("seeds must be distinct non-negative integers")
    if len(set(betas)) != len(betas) or any(not math.isfinite(b) or b <= 0 for b in betas):
        raise ValueError("betas must be distinct, finite and strictly positive")
    return [(int(seed), beta) for seed in seeds for beta in (0., *betas)]


def prepare_phase3(output, seeds=DEFAULT_SEEDS, betas=DEFAULT_PHASE3_BETAS, steps=200_000):
    """Write a fixed manifest before array submission; never tune on phase 3."""
    root = _output(output)
    candidate, checkpoint = _selected_checkpoint(root, 1.0)
    units = phase3_units(tuple(seeds), tuple(betas))
    record = {
        "phase": "checkpoint_continuation_state_gated_manual_steering",
        "source_checkpoint": str(checkpoint),
        "selected_candidate": candidate.name,
        "selected_overrides": candidate.overrides,
        "source_phase1_seed": 0,
        "seeds": list(map(int, seeds)),
        "betas": [0., *map(float, betas)],
        "requested_steps": int(steps),
        "n_runs": len(units),
        "n_chunks": len(units) // 2,
        "manual_signal": "active only before blue collection; exactly zero after collection",
        "optimizer_state": "fresh Adam state in every arm; model weights loaded from source_checkpoint",
    }
    if len(units) != 30:
        raise ValueError("Phase 3 protocol requires five seeds and five non-zero betas (30 total runs)")
    manifest = root / "phase3" / "sweep.json"
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError("Phase 3 settings differ from its sweep.json; use a NEW output directory")
    write_json(manifest, record)
    return record


def run_phase3_chunk(output, chunk_index, n_chunks=15, seeds=DEFAULT_SEEDS,
                     betas=DEFAULT_PHASE3_BETAS, steps=200_000,
                     eval_episodes=200, test_episodes=500,
                     project="ppo-manual-secondary-goal"):
    """Run two matched phase-3 continuations from the same selected checkpoint."""
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    manifest = root / "phase3" / "sweep.json"
    if not manifest.exists():
        raise FileNotFoundError("Missing phase3/sweep.json. Run submit_manual_secondary_phase3.sh first.")
    record = json.loads(manifest.read_text())
    candidate, checkpoint = _selected_checkpoint(root, 1.0)
    units = phase3_units(tuple(seeds), tuple(betas))
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 15 or len(units) != 30 or len(mine) != 2:
        raise ValueError("Phase 3 requires exactly 30 runs split into fifteen two-run chunks")
    results = []
    for seed, beta in mine:
        arm = "ppo" if beta == 0 else "manual_" + str(beta).replace(".", "p")
        out = root / "phase3" / f"seed_{seed}" / arm
        cfg = _make_cfg(candidate, seed, steps, beta, f"manual_phase3_{arm}", checkpoint, 1.0,
                        "3")
        method = "ppo" if beta == 0 else "manual"
        _logger_environment(project, "manual_secondary_phase3_continuation", method,
                            f"manual_secondary,phase-3,continuation,{method},beta-{beta:g},{_checkpoint_tag(1.0)},candidate-{candidate.name}")
        print(f"[phase3 chunk {chunk_index}/{n_chunks}] seed={seed} beta={beta:g}", flush=True)
        print(f"  source checkpoint: {record['source_checkpoint']}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="phase3_continuation").train())
    return results


def phase4a_units(pre_phases=DEFAULT_PHASE4A_PRE_PHASES, seeds=DEFAULT_PHASE4A_SEEDS,
                  betas=DEFAULT_PHASE4A_BETAS):
    """Full pretraining-checkpoint × beta grid, with a control at every checkpoint."""
    if len(set(pre_phases)) != len(pre_phases) or any(not 0 < float(p) <= 1 for p in pre_phases):
        raise ValueError("pre-phases must be distinct fractions in (0, 1]")
    if len(set(seeds)) != len(seeds) or any(int(s) < 0 for s in seeds):
        raise ValueError("seeds must be distinct non-negative integers")
    if len(set(betas)) != len(betas) or any(not math.isfinite(b) or b <= 0 for b in betas):
        raise ValueError("betas must be distinct, finite and strictly positive")
    return [(float(pre), int(seed), beta)
            for pre in pre_phases for seed in seeds for beta in (0., *betas)]


def prepare_phase4a(output, pre_phases=DEFAULT_PHASE4A_PRE_PHASES, seeds=DEFAULT_PHASE4A_SEEDS,
                    betas=DEFAULT_PHASE4A_BETAS, steps=200_000):
    """Freeze the phase-4a factorial design before any worker is submitted."""
    root = _output(output)
    candidate, _ = _selected_checkpoint(root, 1.0)
    for pre in pre_phases:
        _selected_checkpoint(root, float(pre))
    units = phase4a_units(tuple(pre_phases), tuple(seeds), tuple(betas))
    record = {
        "phase": "phase4a_checkpoint_fraction_x_beta_grid",
        "selected_candidate": candidate.name,
        "selected_overrides": candidate.overrides,
        "source_phase1_seed": 0,
        "pre_phases": list(map(float, pre_phases)),
        "seeds": list(map(int, seeds)),
        "betas": [0., *map(float, betas)],
        "requested_steps": int(steps),
        "n_runs": len(units),
        "n_chunks": len(units) // 2,
        "manual_signal": "active only before blue collection; exactly zero after collection",
        "optimizer_state": "fresh Adam state in every arm; model weights loaded from the tagged pre-phase checkpoint",
    }
    if len(units) != 72:
        raise ValueError("Phase 4a requires 4 checkpoints × 3 seeds × (control + 5 betas) = 72 runs")
    manifest = root / "phase4a" / "sweep.json"
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError("Phase 4a settings differ from its sweep.json; use a NEW output directory")
    if not manifest.exists():
        write_json(manifest, record)
    return record


def run_phase4a_chunk(output, chunk_index, n_chunks=24,
                       pre_phases=DEFAULT_PHASE4A_PRE_PHASES, seeds=DEFAULT_PHASE4A_SEEDS,
                       betas=DEFAULT_PHASE4A_BETAS, steps=200_000,
                       eval_episodes=200, test_episodes=500,
                       project="ppo-manual-secondary-goal"):
    """Run two arms of the fixed phase-4a checkpoint-fraction × beta grid."""
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    manifest = root / "phase4a" / "sweep.json"
    if not manifest.exists():
        raise FileNotFoundError("Missing phase4a/sweep.json. Run submit_manual_secondary_phase4a.sh first.")
    record = json.loads(manifest.read_text())
    units = phase4a_units(tuple(pre_phases), tuple(seeds), tuple(betas))
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 24 or len(units) != 72 or len(mine) != 3:
        raise ValueError("Phase 4a requires exactly 72 runs split into twenty-four three-run chunks")
    results = []
    for pre_phase, seed, beta in mine:
        candidate, checkpoint = _selected_checkpoint(root, pre_phase)
        arm = "ppo" if beta == 0 else "manual_" + str(beta).replace(".", "p")
        out = root / "phase4a" / _pre_tag(pre_phase) / f"seed_{seed}" / arm
        cfg = _make_cfg(candidate, seed, steps, beta,
                        f"manual_phase4a_{_pre_tag(pre_phase)}_{arm}", checkpoint, pre_phase, "4a")
        method = "ppo" if beta == 0 else "manual"
        _logger_environment(project, "manual_secondary_phase4a_grid", method,
                            f"manual_secondary,phase-4a,checkpoint-grid,{method},beta-{beta:g},{_checkpoint_tag(pre_phase)},candidate-{candidate.name}")
        print(f"[phase4a chunk {chunk_index}/{n_chunks}] pre={pre_phase:.2f} seed={seed} beta={beta:g}", flush=True)
        print(f"  source checkpoint: {checkpoint}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="phase4a").train())
    return results


def phase4b_units(kappas=DEFAULT_PHASE4B_KAPPAS, seeds=DEFAULT_PHASE4B_SEEDS,
                  treatment_beta=DEFAULT_PHASE4B_BETA):
    if len(set(kappas)) != len(kappas) or any(not 0 <= float(k) <= 1 for k in kappas):
        raise ValueError("kappas must be distinct values in [0, 1]")
    if len(set(seeds)) != len(seeds) or any(int(s) < 0 for s in seeds):
        raise ValueError("seeds must be distinct non-negative integers")
    if not math.isfinite(treatment_beta) or treatment_beta <= 0:
        raise ValueError("treatment_beta must be finite and strictly positive")
    return [(float(kappa), int(seed), beta)
            for kappa in kappas for seed in seeds for beta in (0., float(treatment_beta))]


def prepare_phase4b(output, kappas=DEFAULT_PHASE4B_KAPPAS, seeds=DEFAULT_PHASE4B_SEEDS,
                    treatment_beta=DEFAULT_PHASE4B_BETA, steps=500_000):
    root = _output(output)
    # Fresh initialisation is essential here: changing kappa changes the MDP
    # reward, so loading a policy/critic trained at another kappa would turn
    # this into a transfer study rather than a kappa response experiment.
    candidate = CANDIDATES[0]
    units = phase4b_units(tuple(kappas), tuple(seeds), treatment_beta)
    record = {
        "phase": "phase4b_goal_time_penalty_sweep",
        "selected_candidate": candidate.name,
        "selected_overrides": candidate.overrides,
        "initialization": "fresh random model and optimizer for every arm",
        "kappas": list(map(float, kappas)),
        "seeds": list(map(int, seeds)),
        "betas": [0., float(treatment_beta)],
        "requested_steps": int(steps),
        "n_runs": len(units),
        "n_chunks": len(units) // 3,
        "manual_signal": "unchanged: active only before blue collection; exactly zero after collection",
        "one_knob": "goal_time_penalty kappa; all arms use fresh initialization and fixed treatment beta",
    }
    if len(units) != 24:
        raise ValueError("Phase 4b requires 4 kappas × 3 seeds × (control + treatment) = 24 runs")
    manifest = root / "phase4b" / "sweep.json"
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError("Phase 4b settings differ from its sweep.json; use a NEW output directory")
    if not manifest.exists():
        write_json(manifest, record)
    return record


def run_phase4b_chunk(output, chunk_index, n_chunks=8, kappas=DEFAULT_PHASE4B_KAPPAS,
                       seeds=DEFAULT_PHASE4B_SEEDS, treatment_beta=DEFAULT_PHASE4B_BETA,
                       steps=500_000,
                       eval_episodes=200, test_episodes=500,
                       project="ppo-manual-secondary-goal"):
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    manifest = root / "phase4b" / "sweep.json"
    if not manifest.exists():
        raise FileNotFoundError("Missing phase4b/sweep.json. Run submit_manual_secondary_phase4b.sh first.")
    units = phase4b_units(tuple(kappas), tuple(seeds), treatment_beta)
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 8 or len(units) != 24 or len(mine) != 3:
        raise ValueError("Phase 4b requires exactly 24 runs split into eight three-run chunks")
    results = []
    for kappa, seed, beta in mine:
        candidate = CANDIDATES[0]
        arm = "ppo" if beta == 0 else "manual_" + str(beta).replace(".", "p")
        out = root / "phase4b" / _kappa_tag(kappa) / f"seed_{seed}" / arm
        cfg = _make_cfg(candidate, seed, steps, beta,
                        f"manual_phase4b_{_kappa_tag(kappa)}_{arm}", None, 0.0,
                        "4b", kappa)
        method = "ppo" if beta == 0 else "manual"
        _logger_environment(project, "manual_secondary_phase4b_kappa", method,
                            f"manual_secondary,phase-4b,kappa-sweep,fresh-init,{method},beta-{beta:g},{_kappa_tag(kappa)},candidate-{candidate.name}")
        print(f"[phase4b chunk {chunk_index}/{n_chunks}] kappa={kappa:.1f} seed={seed} beta={beta:g}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="phase4b").train())
    return results


def phase5_units(seeds=DEFAULT_PHASE5_SEEDS, betas=DEFAULT_PHASE5_BETAS):
    """Fresh beta sweep; beta=0 is the ordinary PPO route-choice control."""
    if len(set(seeds)) != len(seeds) or any(int(s) < 0 for s in seeds):
        raise ValueError("seeds must be distinct non-negative integers")
    if len(set(betas)) != len(betas) or any(not math.isfinite(b) or b <= 0 for b in betas):
        raise ValueError("betas must be distinct, finite and strictly positive")
    return [(int(seed), float(beta)) for seed in seeds for beta in (0., *betas)]


def prepare_phase5(output, seeds=DEFAULT_PHASE5_SEEDS, betas=DEFAULT_PHASE5_BETAS,
                   kappa=DEFAULT_PHASE5_KAPPA, steps=500_000):
    if not 0 <= float(kappa) <= 1:
        raise ValueError("kappa must lie in [0, 1]")
    root = _output(output)
    units = phase5_units(tuple(seeds), tuple(betas))
    record = {
        "phase": "phase5_two_route_beta_sweep",
        "environment": "MiniGrid-TwoRouteToken-8x8-v0",
        "initialization": "fresh random model and optimizer for every arm",
        "topology": "short direct corridor versus longer through-corridor with a zero-reward green token; both reach the same goal",
        "primary_reward": "every transition costs kappa/horizon; successful T-step return is 1-kappa*T/horizon",
        "kappa": float(kappa), "seeds": list(map(int, seeds)),
        "betas": [0., *map(float, betas)], "requested_steps": int(steps),
        "n_runs": len(units), "n_chunks": len(units) // 3,
        "manual_signal": "unchanged: distance progress to green token before collection; exactly zero after collection",
        "one_knob": "manual beta; kappa and route geometry remain fixed",
    }
    if len(units) != 18:
        raise ValueError("Phase 5 requires 3 seeds × (PPO control + 5 betas) = 18 runs")
    manifest = root / "phase5" / "sweep.json"
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError("Phase 5 settings differ from its sweep.json; use a NEW output directory")
    if not manifest.exists():
        write_json(manifest, record)
    return record


def run_phase5_chunk(output, chunk_index, n_chunks=6, seeds=DEFAULT_PHASE5_SEEDS,
                     betas=DEFAULT_PHASE5_BETAS, kappa=DEFAULT_PHASE5_KAPPA,
                     steps=500_000, eval_episodes=200, test_episodes=500,
                     project="ppo-manual-secondary-goal"):
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    manifest = root / "phase5" / "sweep.json"
    if not manifest.exists():
        raise FileNotFoundError("Missing phase5/sweep.json. Run submit_manual_secondary_phase5.sh first.")
    units = phase5_units(tuple(seeds), tuple(betas))
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 6 or len(units) != 18 or len(mine) != 3:
        raise ValueError("Phase 5 requires exactly 18 runs split into six three-run chunks")
    results = []
    for seed, beta in mine:
        arm = "ppo" if beta == 0 else "manual_" + str(beta).replace(".", "p")
        out = root / "phase5" / f"seed_{seed}" / arm
        cfg = _make_cfg(CANDIDATES[0], seed, steps, beta, f"manual_phase5_{arm}",
                        None, 0.0, "5", kappa, "tworoute_manual")
        method = "ppo" if beta == 0 else "manual"
        _logger_environment(project, "manual_secondary_phase5_two_route", method,
                            f"manual_secondary,phase-5,two-route,fresh-init,{method},beta-{beta:g},kappa-{kappa:g}")
        print(f"[phase5 chunk {chunk_index}/{n_chunks}] seed={seed} beta={beta:g} kappa={kappa:g}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="phase5").train())
    return results


def phase5b_units(seeds=DEFAULT_PHASE5B_SEEDS, bonus_ratios=DEFAULT_PHASE5B_BONUS_RATIOS):
    if len(set(seeds)) != len(seeds) or any(int(s) < 0 for s in seeds):
        raise ValueError("seeds must be distinct non-negative integers")
    if (len(set(bonus_ratios)) != len(bonus_ratios)
            or any(not math.isfinite(x) or x <= 0 for x in bonus_ratios)):
        raise ValueError("bonus ratios must be distinct, finite and strictly positive")
    return [(int(seed), float(ratio)) for seed in seeds for ratio in (0., *bonus_ratios)]


def prepare_phase5b(output, seeds=DEFAULT_PHASE5B_SEEDS,
                    bonus_ratios=DEFAULT_PHASE5B_BONUS_RATIOS,
                    kappa=DEFAULT_PHASE5B_KAPPA, steps=500_000):
    if not 0 <= float(kappa) <= 1:
        raise ValueError("kappa must lie in [0, 1]")
    root = _output(output)
    units = phase5b_units(tuple(seeds), tuple(bonus_ratios))
    record = {
        "phase": "phase5b_cost_normalized_token_reward_sweep",
        "environment": "MiniGrid-TwoRouteToken-8x8-v0",
        "initialization": "fresh random model and optimizer for every arm",
        "manual_steering": "disabled in every arm; manual.beta is always zero",
        "topology": "same Phase-5 short direct corridor versus longer through-corridor with a green token",
        "primary_reward": "every transition costs kappa/horizon; successful T-step return is 1-kappa*T/horizon",
        "token_reward": "on collection, lambda * kappa * (joint_optimal_steps-direct_steps) / horizon",
        "interpretation": "lambda=1 approximately offsets the undiscounted extra time cost; lambda is comparable across layouts and spans small to high steering-scale doses",
        "kappa": float(kappa), "seeds": list(map(int, seeds)),
        "bonus_ratios": [0., *map(float, bonus_ratios)], "requested_steps": int(steps),
        "n_runs": len(units), "n_chunks": len(units) // 3,
        "one_knob": "external token-bonus ratio lambda; kappa and route geometry remain fixed",
    }
    if len(units) != 24:
        raise ValueError("Phase 5b requires 3 seeds × (zero bonus + 7 bonus ratios) = 24 runs")
    manifest = root / "phase5b" / "sweep.json"
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError("Phase 5b settings differ from its sweep.json; use a NEW output directory")
    if not manifest.exists():
        write_json(manifest, record)
    return record


def run_phase5b_chunk(output, chunk_index, n_chunks=8, seeds=DEFAULT_PHASE5B_SEEDS,
                      bonus_ratios=DEFAULT_PHASE5B_BONUS_RATIOS,
                      kappa=DEFAULT_PHASE5B_KAPPA, steps=500_000,
                      eval_episodes=200, test_episodes=500,
                      project="ppo-manual-secondary-goal"):
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    manifest = root / "phase5b" / "sweep.json"
    if not manifest.exists():
        raise FileNotFoundError("Missing phase5b/sweep.json. Run submit_manual_secondary_phase5b.sh first.")
    units = phase5b_units(tuple(seeds), tuple(bonus_ratios))
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 8 or len(units) != 24 or len(mine) != 3:
        raise ValueError("Phase 5b requires exactly 24 runs split into eight three-run chunks")
    results = []
    for seed, ratio in mine:
        arm = "no_bonus" if ratio == 0 else "reward_" + str(ratio).replace(".", "p")
        out = root / "phase5b" / f"seed_{seed}" / arm
        cfg = _make_cfg(CANDIDATES[0], seed, steps, 0., f"reward_phase5b_{arm}",
                        None, 0.0, "5b", kappa, "tworoute_rewardbonus", ratio)
        _logger_environment(project, "manual_secondary_phase5b_reward_bonus", "reward_bonus",
                            f"manual_secondary,phase-5b,two-route,reward-bonus,fresh-init,bonus-ratio-{ratio:g},kappa-{kappa:g}")
        print(f"[phase5b chunk {chunk_index}/{n_chunks}] seed={seed} bonus_ratio={ratio:g} kappa={kappa:g}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="phase5b_reward_bonus").train())
    return results


def phase5c_units(seeds=DEFAULT_PHASE5C_SEEDS, bonus_ratios=DEFAULT_PHASE5C_BONUS_RATIOS):
    return phase5b_units(seeds, bonus_ratios)


def prepare_phase5c(output, seeds=DEFAULT_PHASE5C_SEEDS,
                    bonus_ratios=DEFAULT_PHASE5C_BONUS_RATIOS,
                    kappa=DEFAULT_PHASE5C_KAPPA,
                    layout_seed=DEFAULT_PHASE5C_LAYOUT_SEED, steps=500_000):
    if not 0 <= float(kappa) <= 1:
        raise ValueError("kappa must lie in [0, 1]")
    root = _output(output)
    units = phase5c_units(tuple(seeds), tuple(bonus_ratios))
    record = {
        "phase": "phase5c_fixed_layout_cost_normalized_token_reward_sweep",
        "environment": "MiniGrid-TwoRouteToken-8x8-v0",
        "initialization": "fresh random model and optimizer for every arm",
        "manual_steering": "disabled in every arm; manual.beta is always zero",
        "sole_change_from_phase5b": "all episodes use layout seed 0, fixing topology, reflection, rotation, and initial heading",
        "layout_seed": int(layout_seed),
        "primary_reward": "every transition costs kappa/horizon; successful T-step return is 1-kappa*T/horizon",
        "token_reward": "on collection, lambda * kappa * (joint_optimal_steps-direct_steps) / horizon",
        "kappa": float(kappa), "seeds": list(map(int, seeds)),
        "bonus_ratios": [0., *map(float, bonus_ratios)], "requested_steps": int(steps),
        "n_runs": len(units), "n_chunks": len(units) // 3,
        "one_knob": "external token-bonus ratio lambda; all layout variation is deliberately removed",
    }
    if len(units) != 24:
        raise ValueError("Phase 5c requires 3 seeds × (zero bonus + 7 bonus ratios) = 24 runs")
    manifest = root / "phase5c" / "sweep.json"
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError("Phase 5c settings differ from its sweep.json; use a NEW output directory")
    if not manifest.exists():
        write_json(manifest, record)
    return record


def run_phase5c_chunk(output, chunk_index, n_chunks=8, seeds=DEFAULT_PHASE5C_SEEDS,
                      bonus_ratios=DEFAULT_PHASE5C_BONUS_RATIOS,
                      kappa=DEFAULT_PHASE5C_KAPPA,
                      layout_seed=DEFAULT_PHASE5C_LAYOUT_SEED, steps=500_000,
                      eval_episodes=200, test_episodes=500,
                      project="ppo-manual-secondary-goal"):
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    manifest = root / "phase5c" / "sweep.json"
    if not manifest.exists():
        raise FileNotFoundError("Missing phase5c/sweep.json. Run submit_manual_secondary_phase5c.sh first.")
    units = phase5c_units(tuple(seeds), tuple(bonus_ratios))
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 8 or len(units) != 24 or len(mine) != 3:
        raise ValueError("Phase 5c requires exactly 24 runs split into eight three-run chunks")
    results = []
    for seed, ratio in mine:
        arm = "no_bonus" if ratio == 0 else "reward_" + str(ratio).replace(".", "p")
        out = root / "phase5c" / f"seed_{seed}" / arm
        cfg = _make_cfg(CANDIDATES[0], seed, steps, 0., f"reward_phase5c_{arm}",
                        None, 0.0, "5c", kappa, "tworoute_rewardbonus", ratio, layout_seed)
        _logger_environment(project, "manual_secondary_phase5c_fixed_layout", "reward_bonus",
                            f"manual_secondary,phase-5c,two-route,fixed-layout,reward-bonus,fresh-init,lambda-{ratio:g},kappa-{kappa:g}")
        print(f"[phase5c chunk {chunk_index}/{n_chunks}] seed={seed} lambda={ratio:g} kappa={kappa:g} layout={layout_seed}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="phase5c_fixed_layout").train())
    return results


def phase5d_units(seeds=DEFAULT_PHASE5D_SEEDS,
                  reward_lambdas=DEFAULT_PHASE5D_REWARD_LAMBDAS,
                  perturb_betas=DEFAULT_PHASE5D_PERTURB_BETAS):
    if len(set(seeds)) != len(seeds) or any(int(s) < 0 for s in seeds):
        raise ValueError("seeds must be distinct non-negative integers")
    for name, values in (("reward lambdas", reward_lambdas), ("perturbation betas", perturb_betas)):
        if len(set(values)) != len(values) or any(not math.isfinite(x) or x <= 0 for x in values):
            raise ValueError(f"{name} must be distinct, finite and strictly positive")
    units = []
    for layout_mode in ("random", "fixed"):
        for seed in seeds:
            units.extend((layout_mode, int(seed), "reward", float(value)) for value in reward_lambdas)
            units.extend((layout_mode, int(seed), "perturb", float(value)) for value in perturb_betas)
    return units


def prepare_phase5d(output, seeds=DEFAULT_PHASE5D_SEEDS,
                    reward_lambdas=DEFAULT_PHASE5D_REWARD_LAMBDAS,
                    perturb_betas=DEFAULT_PHASE5D_PERTURB_BETAS,
                    kappa=DEFAULT_PHASE5D_KAPPA,
                    fixed_layout_seed=DEFAULT_PHASE5D_FIXED_LAYOUT_SEED,
                    steps=1_000_000):
    if not 0 <= float(kappa) <= 1:
        raise ValueError("kappa must lie in [0, 1]")
    root = _output(output)
    units = phase5d_units(tuple(seeds), tuple(reward_lambdas), tuple(perturb_betas))
    record = {
        "phase": "phase5d_reward_vs_perturb_matched_scaler_grid",
        "environment": "MiniGrid-TwoRouteToken-8x8-v0",
        "initialization": "fresh random model and optimizer for every arm",
        "layout_modes": {"random": "fresh rotated/reflected layout and heading each episode",
                         "fixed": f"layout seed {int(fixed_layout_seed)} every episode"},
        "methods": {
            "reward": {"values": list(map(float, reward_lambdas)),
                       "mechanism": "external token bonus lambda * kappa * extra_steps / horizon; manual beta is zero"},
            "perturb": {"values": list(map(float, perturb_betas)),
                        "mechanism": "pre-token actor-advantage perturbation beta; external token bonus is zero"},
        },
        "test_scaler": "the method-specific lambda or beta value, logged uniformly as test.scaler",
        "kappa": float(kappa), "seeds": list(map(int, seeds)),
        "fixed_layout_seed": int(fixed_layout_seed), "requested_steps": int(steps),
        "n_runs": len(units), "n_chunks": len(units) // 3,
        "primary_metrics": "goal_success; joint_success means token collected and then goal reached for both methods",
    }
    if len(units) != 48:
        raise ValueError("Phase 5d requires 2 layout modes × 3 seeds × 4 scalers × 2 methods = 48 runs")
    manifest = root / "phase5d" / "sweep.json"
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise ValueError("Phase 5d settings differ from its sweep.json; use a NEW output directory")
    if not manifest.exists():
        write_json(manifest, record)
    return record


def run_phase5d_chunk(output, chunk_index, n_chunks=16, seeds=DEFAULT_PHASE5D_SEEDS,
                      reward_lambdas=DEFAULT_PHASE5D_REWARD_LAMBDAS,
                      perturb_betas=DEFAULT_PHASE5D_PERTURB_BETAS,
                      kappa=DEFAULT_PHASE5D_KAPPA,
                      fixed_layout_seed=DEFAULT_PHASE5D_FIXED_LAYOUT_SEED,
                      steps=1_000_000, eval_episodes=200, test_episodes=500,
                      project="ppo-manual-secondary-goal"):
    from manual_steering.trainer import ManualTrainer
    root = _output(output)
    manifest = root / "phase5d" / "sweep.json"
    if not manifest.exists():
        raise FileNotFoundError("Missing phase5d/sweep.json. Run submit_manual_secondary_phase5d.sh first.")
    units = phase5d_units(tuple(seeds), tuple(reward_lambdas), tuple(perturb_betas))
    mine = contiguous_slice(units, int(chunk_index), int(n_chunks))
    if n_chunks != 16 or len(units) != 48 or len(mine) != 3:
        raise ValueError("Phase 5d requires exactly 48 runs split into sixteen three-run chunks")
    results = []
    for layout_mode, seed, method, scaler in mine:
        fixed_seed = int(fixed_layout_seed) if layout_mode == "fixed" else None
        beta = scaler if method == "perturb" else 0.0
        token_bonus = scaler if method == "reward" else 0.0
        arm = f"{layout_mode}_{method}_{str(scaler).replace('.', 'p')}"
        out = root / "phase5d" / layout_mode / f"seed_{seed}" / arm
        cfg = _make_cfg(
            CANDIDATES[0], seed, steps, beta, f"phase5d_{arm}",
            experiment_phase="5d", goal_time_penalty=kappa,
            env_config="tworoute_rewardbonus", token_bonus_ratio=token_bonus,
            fixed_layout_seed=fixed_seed, test_scaler=scaler, test_method=method,
            test_layout_mode=layout_mode,
        )
        _logger_environment(project, "manual_secondary_phase5d_comparison", method,
                            f"manual_secondary,phase-5d,two-route,layout-{layout_mode},method-{method},scaler-{scaler:g},kappa-{kappa:g}")
        print(f"[phase5d chunk {chunk_index}/{n_chunks}] layout={layout_mode} seed={seed} method={method} test.scaler={scaler:g}", flush=True)
        print(cfg.summary(), flush=True)
        results.append(ManualTrainer(cfg, seed, out, eval_episodes, test_episodes,
                                     phase="phase5d").train())
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    tune = sub.add_parser("tune")
    tune.add_argument("--output", default="runs/manual_secondary_two_phase")
    tune.add_argument("--candidate-index", type=int, required=True)
    tune.add_argument("--seed", type=int, default=0)
    tune.add_argument("--steps", type=int, default=500_000)
    tune.add_argument("--eval-episodes", type=int, default=200)
    tune.add_argument("--test-episodes", type=int, default=500)
    tune.add_argument("--project", default="ppo-manual-secondary-goal")
    select = sub.add_parser("select")
    select.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase2 = sub.add_parser("phase2")
    phase2.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase2.add_argument("--chunk-index", type=int, required=True)
    phase2.add_argument("--n-chunks", type=int, default=10)
    phase2.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_SEEDS))
    phase2.add_argument("--betas", type=float, nargs="+", default=list(DEFAULT_BETAS))
    phase2.add_argument("--steps", type=int, default=500_000)
    phase2.add_argument("--eval-episodes", type=int, default=200)
    phase2.add_argument("--test-episodes", type=int, default=500)
    phase2.add_argument("--project", default="ppo-manual-secondary-goal")
    phase3_manifest = sub.add_parser("phase3-manifest")
    phase3_manifest.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase3_manifest.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_SEEDS))
    phase3_manifest.add_argument("--betas", type=float, nargs="+", default=list(DEFAULT_PHASE3_BETAS))
    phase3_manifest.add_argument("--steps", type=int, default=200_000)
    phase3 = sub.add_parser("phase3")
    phase3.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase3.add_argument("--chunk-index", type=int, required=True)
    phase3.add_argument("--n-chunks", type=int, default=15)
    phase3.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_SEEDS))
    phase3.add_argument("--betas", type=float, nargs="+", default=list(DEFAULT_PHASE3_BETAS))
    phase3.add_argument("--steps", type=int, default=200_000)
    phase3.add_argument("--eval-episodes", type=int, default=200)
    phase3.add_argument("--test-episodes", type=int, default=500)
    phase3.add_argument("--project", default="ppo-manual-secondary-goal")
    phase4a_manifest = sub.add_parser("phase4a-manifest")
    phase4a_manifest.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase4a_manifest.add_argument("--pre-phases", type=float, nargs="+", default=list(DEFAULT_PHASE4A_PRE_PHASES))
    phase4a_manifest.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE4A_SEEDS))
    phase4a_manifest.add_argument("--betas", type=float, nargs="+", default=list(DEFAULT_PHASE4A_BETAS))
    phase4a_manifest.add_argument("--steps", type=int, default=200_000)
    phase4a = sub.add_parser("phase4a")
    phase4a.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase4a.add_argument("--chunk-index", type=int, required=True)
    phase4a.add_argument("--n-chunks", type=int, default=24)
    phase4a.add_argument("--pre-phases", type=float, nargs="+", default=list(DEFAULT_PHASE4A_PRE_PHASES))
    phase4a.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE4A_SEEDS))
    phase4a.add_argument("--betas", type=float, nargs="+", default=list(DEFAULT_PHASE4A_BETAS))
    phase4a.add_argument("--steps", type=int, default=200_000)
    phase4a.add_argument("--eval-episodes", type=int, default=200)
    phase4a.add_argument("--test-episodes", type=int, default=500)
    phase4a.add_argument("--project", default="ppo-manual-secondary-goal")
    phase4b_manifest = sub.add_parser("phase4b-manifest")
    phase4b_manifest.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase4b_manifest.add_argument("--kappas", type=float, nargs="+", default=list(DEFAULT_PHASE4B_KAPPAS))
    phase4b_manifest.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE4B_SEEDS))
    phase4b_manifest.add_argument("--treatment-beta", type=float, default=DEFAULT_PHASE4B_BETA)
    phase4b_manifest.add_argument("--steps", type=int, default=500_000)
    phase4b = sub.add_parser("phase4b")
    phase4b.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase4b.add_argument("--chunk-index", type=int, required=True)
    phase4b.add_argument("--n-chunks", type=int, default=8)
    phase4b.add_argument("--kappas", type=float, nargs="+", default=list(DEFAULT_PHASE4B_KAPPAS))
    phase4b.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE4B_SEEDS))
    phase4b.add_argument("--treatment-beta", type=float, default=DEFAULT_PHASE4B_BETA)
    phase4b.add_argument("--steps", type=int, default=500_000)
    phase4b.add_argument("--eval-episodes", type=int, default=200)
    phase4b.add_argument("--test-episodes", type=int, default=500)
    phase4b.add_argument("--project", default="ppo-manual-secondary-goal")
    phase5_manifest = sub.add_parser("phase5-manifest")
    phase5_manifest.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5_manifest.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5_SEEDS))
    phase5_manifest.add_argument("--betas", type=float, nargs="+", default=list(DEFAULT_PHASE5_BETAS))
    phase5_manifest.add_argument("--kappa", type=float, default=DEFAULT_PHASE5_KAPPA)
    phase5_manifest.add_argument("--steps", type=int, default=500_000)
    phase5 = sub.add_parser("phase5")
    phase5.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5.add_argument("--chunk-index", type=int, required=True)
    phase5.add_argument("--n-chunks", type=int, default=6)
    phase5.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5_SEEDS))
    phase5.add_argument("--betas", type=float, nargs="+", default=list(DEFAULT_PHASE5_BETAS))
    phase5.add_argument("--kappa", type=float, default=DEFAULT_PHASE5_KAPPA)
    phase5.add_argument("--steps", type=int, default=500_000)
    phase5.add_argument("--eval-episodes", type=int, default=200)
    phase5.add_argument("--test-episodes", type=int, default=500)
    phase5.add_argument("--project", default="ppo-manual-secondary-goal")
    phase5b_manifest = sub.add_parser("phase5b-manifest")
    phase5b_manifest.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5b_manifest.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5B_SEEDS))
    phase5b_manifest.add_argument("--bonus-ratios", type=float, nargs="+", default=list(DEFAULT_PHASE5B_BONUS_RATIOS))
    phase5b_manifest.add_argument("--kappa", type=float, default=DEFAULT_PHASE5B_KAPPA)
    phase5b_manifest.add_argument("--steps", type=int, default=500_000)
    phase5b = sub.add_parser("phase5b")
    phase5b.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5b.add_argument("--chunk-index", type=int, required=True)
    phase5b.add_argument("--n-chunks", type=int, default=8)
    phase5b.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5B_SEEDS))
    phase5b.add_argument("--bonus-ratios", type=float, nargs="+", default=list(DEFAULT_PHASE5B_BONUS_RATIOS))
    phase5b.add_argument("--kappa", type=float, default=DEFAULT_PHASE5B_KAPPA)
    phase5b.add_argument("--steps", type=int, default=500_000)
    phase5b.add_argument("--eval-episodes", type=int, default=200)
    phase5b.add_argument("--test-episodes", type=int, default=500)
    phase5b.add_argument("--project", default="ppo-manual-secondary-goal")
    phase5c_manifest = sub.add_parser("phase5c-manifest")
    phase5c_manifest.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5c_manifest.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5C_SEEDS))
    phase5c_manifest.add_argument("--bonus-ratios", type=float, nargs="+", default=list(DEFAULT_PHASE5C_BONUS_RATIOS))
    phase5c_manifest.add_argument("--kappa", type=float, default=DEFAULT_PHASE5C_KAPPA)
    phase5c_manifest.add_argument("--layout-seed", type=int, default=DEFAULT_PHASE5C_LAYOUT_SEED)
    phase5c_manifest.add_argument("--steps", type=int, default=500_000)
    phase5c = sub.add_parser("phase5c")
    phase5c.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5c.add_argument("--chunk-index", type=int, required=True)
    phase5c.add_argument("--n-chunks", type=int, default=8)
    phase5c.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5C_SEEDS))
    phase5c.add_argument("--bonus-ratios", type=float, nargs="+", default=list(DEFAULT_PHASE5C_BONUS_RATIOS))
    phase5c.add_argument("--kappa", type=float, default=DEFAULT_PHASE5C_KAPPA)
    phase5c.add_argument("--layout-seed", type=int, default=DEFAULT_PHASE5C_LAYOUT_SEED)
    phase5c.add_argument("--steps", type=int, default=500_000)
    phase5c.add_argument("--eval-episodes", type=int, default=200)
    phase5c.add_argument("--test-episodes", type=int, default=500)
    phase5c.add_argument("--project", default="ppo-manual-secondary-goal")
    phase5d_manifest = sub.add_parser("phase5d-manifest")
    phase5d_manifest.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5d_manifest.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5D_SEEDS))
    phase5d_manifest.add_argument("--reward-lambdas", type=float, nargs="+", default=list(DEFAULT_PHASE5D_REWARD_LAMBDAS))
    phase5d_manifest.add_argument("--perturb-betas", type=float, nargs="+", default=list(DEFAULT_PHASE5D_PERTURB_BETAS))
    phase5d_manifest.add_argument("--kappa", type=float, default=DEFAULT_PHASE5D_KAPPA)
    phase5d_manifest.add_argument("--fixed-layout-seed", type=int, default=DEFAULT_PHASE5D_FIXED_LAYOUT_SEED)
    phase5d_manifest.add_argument("--steps", type=int, default=1_000_000)
    phase5d = sub.add_parser("phase5d")
    phase5d.add_argument("--output", default="runs/manual_secondary_two_phase")
    phase5d.add_argument("--chunk-index", type=int, required=True)
    phase5d.add_argument("--n-chunks", type=int, default=16)
    phase5d.add_argument("--seeds", type=int, nargs="+", default=list(DEFAULT_PHASE5D_SEEDS))
    phase5d.add_argument("--reward-lambdas", type=float, nargs="+", default=list(DEFAULT_PHASE5D_REWARD_LAMBDAS))
    phase5d.add_argument("--perturb-betas", type=float, nargs="+", default=list(DEFAULT_PHASE5D_PERTURB_BETAS))
    phase5d.add_argument("--kappa", type=float, default=DEFAULT_PHASE5D_KAPPA)
    phase5d.add_argument("--fixed-layout-seed", type=int, default=DEFAULT_PHASE5D_FIXED_LAYOUT_SEED)
    phase5d.add_argument("--steps", type=int, default=1_000_000)
    phase5d.add_argument("--eval-episodes", type=int, default=200)
    phase5d.add_argument("--test-episodes", type=int, default=500)
    phase5d.add_argument("--project", default="ppo-manual-secondary-goal")
    args = parser.parse_args()
    if args.command == "tune":
        run_tune(args.output, args.candidate_index, args.seed, args.steps, args.eval_episodes,
                 args.test_episodes, args.project)
    elif args.command == "select":
        print(json.dumps(select_best(args.output), indent=2), flush=True)
    elif args.command == "phase2":
        run_phase2_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.seeds),
                         tuple(args.betas), args.steps, args.eval_episodes, args.test_episodes,
                         args.project)
    elif args.command == "phase3-manifest":
        print(json.dumps(prepare_phase3(args.output, tuple(args.seeds), tuple(args.betas),
                                         args.steps), indent=2), flush=True)
    elif args.command == "phase3":
        run_phase3_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.seeds),
                         tuple(args.betas), args.steps, args.eval_episodes, args.test_episodes,
                         args.project)
    elif args.command == "phase4a-manifest":
        print(json.dumps(prepare_phase4a(args.output, tuple(args.pre_phases), tuple(args.seeds),
                                          tuple(args.betas), args.steps), indent=2), flush=True)
    elif args.command == "phase4a":
        run_phase4a_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.pre_phases),
                          tuple(args.seeds), tuple(args.betas), args.steps, args.eval_episodes,
                          args.test_episodes, args.project)
    elif args.command == "phase4b-manifest":
        print(json.dumps(prepare_phase4b(args.output, tuple(args.kappas), tuple(args.seeds),
                                          args.treatment_beta, args.steps), indent=2), flush=True)
    elif args.command == "phase4b":
        run_phase4b_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.kappas),
                          tuple(args.seeds), args.treatment_beta, args.steps,
                          args.eval_episodes, args.test_episodes, args.project)
    elif args.command == "phase5-manifest":
        print(json.dumps(prepare_phase5(args.output, tuple(args.seeds), tuple(args.betas),
                                         args.kappa, args.steps), indent=2), flush=True)
    elif args.command == "phase5":
        run_phase5_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.seeds),
                         tuple(args.betas), args.kappa, args.steps,
                         args.eval_episodes, args.test_episodes, args.project)
    elif args.command == "phase5b-manifest":
        print(json.dumps(prepare_phase5b(args.output, tuple(args.seeds), tuple(args.bonus_ratios),
                                          args.kappa, args.steps), indent=2), flush=True)
    elif args.command == "phase5b":
        run_phase5b_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.seeds),
                          tuple(args.bonus_ratios), args.kappa, args.steps,
                          args.eval_episodes, args.test_episodes, args.project)
    elif args.command == "phase5c-manifest":
        print(json.dumps(prepare_phase5c(args.output, tuple(args.seeds), tuple(args.bonus_ratios),
                                          args.kappa, args.layout_seed, args.steps), indent=2), flush=True)
    elif args.command == "phase5c":
        run_phase5c_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.seeds),
                          tuple(args.bonus_ratios), args.kappa, args.layout_seed, args.steps,
                          args.eval_episodes, args.test_episodes, args.project)
    elif args.command == "phase5d-manifest":
        print(json.dumps(prepare_phase5d(args.output, tuple(args.seeds), tuple(args.reward_lambdas),
                                          tuple(args.perturb_betas), args.kappa,
                                          args.fixed_layout_seed, args.steps), indent=2), flush=True)
    else:
        run_phase5d_chunk(args.output, args.chunk_index, args.n_chunks, tuple(args.seeds),
                          tuple(args.reward_lambdas), tuple(args.perturb_betas), args.kappa,
                          args.fixed_layout_seed, args.steps, args.eval_episodes,
                          args.test_episodes, args.project)


if __name__ == "__main__":
    main()
