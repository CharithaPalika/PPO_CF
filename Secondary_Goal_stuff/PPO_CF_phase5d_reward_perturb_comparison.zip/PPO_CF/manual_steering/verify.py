"""Verification: --logic-only works without torch/gym; --full MUST have them.

All test outputs go into a new temporary directory. No real runs are changed.
"""
from __future__ import annotations
import argparse
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from manual_steering.geometry import (BUCKETS, DIRECTIONS, distances, generate,
                                     manual_signal, path, successor)
from manual_steering.io import write_csv, write_json


class GeometryTests(unittest.TestCase):
    def test_1000_valid_random_layouts(self):
        orientations, hashes, buckets = set(), set(), set()
        for seed in range(1000):
            layout = generate(seed)
            direct, joint = path(layout), path(layout, True)
            self.assertLess(len(direct), len(joint))
            self.assertLess(len(joint), 32)
            self.assertNotEqual(layout.goal, layout.token)
            self.assertTrue(all(0 < x < 7 and 0 < y < 7 for x, y in layout.cells))
            self.assertEqual(layout, generate(seed))
            hashes.add(layout.fingerprint)
            orientations.add(layout.direction)
            buckets.add(layout.bucket)
        self.assertEqual(orientations, set(range(4)))
        self.assertEqual(buckets, set(BUCKETS))
        self.assertGreater(len(hashes), 500)

    def test_exact_bounded_signal_and_off_switch(self):
        for before in range(25):
            for after in range(25):
                self.assertEqual(manual_signal(False, False, before, after), 0)
                self.assertEqual(manual_signal(False, True, before, after), 0)
                if -5 <= before - after <= 1:
                    self.assertLessEqual(abs(manual_signal(True, False, before, after)), 1)
        self.assertEqual(manual_signal(True, True, 1, 0), 1)
        layout = generate(15)
        dist = distances(layout.cells, layout.token, (layout.goal,))
        # At least one orientation requires turning on a shortest token path.
        useful_turns = 0
        for pose, d in dist.items():
            for a in (0, 1, 2):
                nxt = successor(pose, a, layout.cells - {layout.goal})
                if nxt in dist:
                    self.assertLessEqual(d - dist[nxt], 1)
                    self.assertLessEqual(dist[nxt] - d, 5)
                    useful_turns += a < 2 and dist[nxt] < d
        self.assertGreater(useful_turns, 0)
        # Turning all the way round must not accumulate a preference bonus.
        for pose in dist:
            current, total = pose, 0.
            for _ in range(4):
                nxt = successor(current, 0, layout.cells)
                total += manual_signal(True, False, dist[current], dist[nxt])
                current = nxt
            self.assertAlmostEqual(total, 0.)

    def test_plotting_without_cherry_picking(self):
        from manual_steering.plotting import mean_ci, paired_costs, plot_results
        self.assertTrue(np.isnan(mean_ci([1])[1]))
        # Deliberately NON-monotonic data; this tests plots, not the hypothesis.
        with tempfile.TemporaryDirectory(prefix="manual_plot_test_") as temp:
            root = Path(temp)
            write_json(root / "sweep.json", {"seeds": [0, 1], "betas": [0, .75, 1.5]})
            for seed in (0, 1):
                for beta in (0., .75, 1.5):
                    rows = []
                    for split, steps in (("validation", (0, 128)), ("test", (128,))):
                        for step in steps:
                            for ep, bucket in enumerate(BUCKETS):
                                primary = .7 + .1 * (beta == .75) - .2 * (beta == 1.5)
                                rows.append(dict(seed=seed, beta=beta, global_step=step, split=split,
                                    eval_episode=ep, eval_seed=9_000_000+ep,
                                    evaluation_policy="stochastic", primary_return=primary+.01*seed,
                                    goal_success=1, token_success=int(beta > 0),
                                    joint_success=int(beta > 0), timeout=0, episode_length=10+beta,
                                    detour_bucket=bucket, detour_extra_steps=6+ep*5))
                    run = root / f"seed_{seed}" / "finetune" / str(beta)
                    write_json(run / "completed.json", {"beta": beta})
                    write_csv(run / "evaluation.csv", rows)
            plot_results(root, title="SYNTHETIC VERIFICATION DATA — NOT EXPERIMENT RESULTS")
            import pandas as pd
            costs = pd.read_csv(root / "tables" / "paired_tradeoffs.csv")
            self.assertTrue((costs[costs.beta == .75].primary_cost < 0).all())
            self.assertEqual(len(list((root / "figures").glob("*.png"))), 4)
            # Optional image inspection location is printed, not retained as results.
            self.assertTrue((root / "tables" / "summary.csv").exists())


class RuntimeTests(unittest.TestCase):
    def cfg(self, beta=0., steps=256):
        from config import make_config
        return make_config("detourpickup_manual", **{
            "env.n_envs": 4, "ppo.n_steps": 32, "ppo.total_timesteps": steps,
            "manual.beta": beta, "manual.enabled": beta > 0,
            "run.log_every_updates": 1, "run.run_name": "_manual_verification"})

    def test_environment_contract_and_restore(self):
        from envs.env_pool import make_env
        from manual_steering.environment import ENV_ID
        env = make_env(ENV_ID, 64)
        try:
            for seed in range(30):
                obs, _ = env.reset(seed=seed)
                self.assertTrue(env.observation_space.contains(obs))
                self.assertEqual(obs.shape, (8, 8, 4))
                u = env.unwrapped
                route = path(u.layout, True)
                seen = False
                for n, action in enumerate(route, 1):
                    obs, reward, term, trunc, info = env.step(action)
                    if seen:
                        self.assertEqual(info["manual_signal"], 0.)
                    if info["token_collected"]:
                        seen = True
                    if n < len(route):
                        self.assertEqual(reward, 0.)
                        self.assertFalse(term or trunc)
                self.assertTrue(info["primary_success"] and info["joint_success"])
                self.assertAlmostEqual(reward, 1 - .9 * len(route) / 64)
            env.reset(seed=8)
            u = env.unwrapped
            saved = u.state_dict()
            first = env.step(0)
            u.load_state_dict(saved)
            second = env.step(0)
            np.testing.assert_array_equal(first[0], second[0])
            self.assertEqual(first[1:], second[1:])
            env.reset(seed=42)
            for _ in range(64):
                obs, reward, term, trunc, info = env.step(6)
            self.assertTrue(term and info["timeout"])
            self.assertFalse(trunc or info["primary_success"])
            self.assertEqual(reward, 0.)
            self.assertTrue(np.all(obs[:, :, 3] == 0))
        finally:
            env.close()

    def test_beta_zero_and_primary_critic_invariance(self):
        import torch
        from agents.ppo import PPOTrainer
        from manual_steering.trainer import ManualTrainer
        torch.set_num_threads(1)
        with tempfile.TemporaryDirectory(prefix="manual_update_test_") as temp:
            base = PPOTrainer(self.cfg(), 7, Path(temp)/"base", progress=False)
            base.pool.reset()
            base.collect_rollout()
            adv, ret = base.compute_advantages()
            base_actions = base.buffer.actions.copy()
            base.update(adv.copy(), ret.copy())
            reference = {k:v.detach().clone() for k,v in base.model.state_dict().items()}
            base.logger.close()
            base.pool.close()
            for beta in (0., 1.5):
                trainer = ManualTrainer(self.cfg(beta), 7, Path(temp)/str(beta),
                                        eval_episodes=3, test_episodes=3, progress=False)
                trainer.pool.reset()
                trainer.collect_rollout()
                a, r = trainer.compute_advantages()
                np.testing.assert_array_equal(trainer.buffer.actions, base_actions)
                np.testing.assert_array_equal(r, ret)
                np.testing.assert_array_equal(a, adv)
                trainer.update(a, r)
                changed_actor = False
                for key, value in trainer.model.state_dict().items():
                    if beta == 0 or key.startswith(("critic", "value")):
                        torch.testing.assert_close(value, reference[key], rtol=0, atol=0)
                    elif not torch.equal(value, reference[key]):
                        changed_actor = True
                if beta > 0:
                    self.assertTrue(changed_actor)
                trainer.logger.close()
                trainer.pool.close()

    def test_autoreset_keeps_terminal_secondary_info(self):
        from manual_steering.trainer import ManualTrainer
        with tempfile.TemporaryDirectory(prefix="manual_reset_test_") as temp:
            trainer = ManualTrainer(self.cfg(), 8, temp, 3, 3, progress=False)
            try:
                trainer.pool.reset()
                routes = [path(e.unwrapped.layout, True) for e in trainer.pool.envs]
                for t in range(max(map(len, routes))):
                    actions = np.array([route[t] if t < len(route) else 6 for route in routes])
                    out = trainer.pool.step(actions)
                    for episode in out["finished"]:
                        self.assertTrue(episode["joint_success"])
                        self.assertTrue(out["infos"][episode["env_id"]]["token_collected"])
            finally:
                trainer.logger.close()
                trainer.pool.close()

    def test_resume_matches_uninterrupted(self):
        import torch
        from manual_steering.trainer import ManualTrainer
        torch.set_num_threads(1)
        cfg = self.cfg(.75, 512)
        with tempfile.TemporaryDirectory(prefix="manual_resume_test_") as temp:
            root = Path(temp)
            full = ManualTrainer(cfg, 19, root/"full", 3, 3, progress=False)
            result = full.train()
            interrupted = ManualTrainer(cfg, 19, root/"resumed", 3, 3, progress=False)
            self.assertTrue(interrupted.train(stop_after_updates=2)["paused"])
            resumed = ManualTrainer(cfg, 19, root/"resumed", 3, 3, progress=False)
            second = resumed.train()
            self.assertTrue(resumed.resumed)
            self.assertEqual(result["global_step"], second["global_step"])
            self.assertEqual(result["test"], second["test"])
            for k, v in full.model.state_dict().items():
                torch.testing.assert_close(v, resumed.model.state_dict()[k], rtol=0, atol=0)

    def test_wandb_grouping_fields(self):
        import os
        from unittest.mock import patch
        from types import SimpleNamespace
        from utils.wandb_sink import make_sinks
        seen = []
        fake = SimpleNamespace(init=lambda **kwargs: seen.append(kwargs) or SimpleNamespace(finish=lambda: None))
        with patch.dict("sys.modules", {"wandb": fake}), patch.dict(os.environ, {
            "PPO_CF_WANDB": "1", "WANDB_MODE": "online", "PPO_CF_WANDB_RESUME": "allow",
            "PPO_CF_WANDB_RUN_NAMESPACE": "manual_test"}, clear=False):
            sinks = make_sinks(self.cfg(.75), 0)
            sinks[0].close()
        cfg = seen[0]["config"]
        self.assertEqual(cfg["ppo.pg_mode"], "gae")
        self.assertEqual(cfg["env.env_id"], "MiniGrid-DetourPickup-8x8-v0")
        self.assertEqual(cfg["manual.beta"], .75)
        self.assertEqual(cfg["manual.method"], "manual")

    def test_e0_e3_configs_still_build(self):
        from pipeline.stages import STAGES, GROUPS_ALL, build_config
        for stage in STAGES:
            if stage in ("E2_ALL", "E3_ALL"):
                continue
            groups = ("queried", "distill") if stage.startswith("E2_") else (
                ("uniform", "uncertainty", "active") if stage.startswith("E3_") else GROUPS_ALL)
            for group in groups:
                self.assertFalse(build_config(stage, group, 0).manual.enabled)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--logic-only", action="store_true")
    mode.add_argument("--full", action="store_true")
    args = parser.parse_args()
    suites = [unittest.defaultTestLoader.loadTestsFromTestCase(GeometryTests)]
    if args.full:
        missing = [m for m in ("torch", "gymnasium", "minigrid") if importlib.util.find_spec(m) is None]
        if missing:
            parser.exit(2, f"FULL VERIFICATION NOT RUN: missing {missing}. Install requirements.txt first.\n")
        import os
        os.environ["PPO_CF_WANDB"] = "0"  # fake-wandb unit test overrides this locally
        suites.append(unittest.defaultTestLoader.loadTestsFromTestCase(RuntimeTests))
    result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(suites))
    if not result.wasSuccessful():
        raise SystemExit(1)
    print("FULL VERIFICATION PASSED" if args.full else
          "LOGIC/PLOTTING CHECKS PASSED; PyTorch/MiniGrid integration NOT verified.")


if __name__ == "__main__":
    main()
