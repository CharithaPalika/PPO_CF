#!/bin/bash
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?submit from the repository root}"
source slurm/_prelude.sh
case "${1:?expected tune|select|phase2}" in
  tune) exec python -m manual_steering.two_phase tune --output "$MANUAL_OUTPUT" --candidate-index "${SLURM_ARRAY_TASK_ID:?}" --project "$PPO_CF_WANDB_PROJECT" ;;
  select) exec python -m manual_steering.two_phase select --output "$MANUAL_OUTPUT" ;;
  phase2) exec python -m manual_steering.two_phase phase2 --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 10 --seeds 0 1 2 3 4 --betas 0.25 0.75 1.5 --project "$PPO_CF_WANDB_PROJECT" ;;
  phase3) exec python -m manual_steering.two_phase phase3 --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 15 --seeds 0 1 2 3 4 --betas 0.25 0.75 1.5 3.0 5.0 --steps 200000 --project "$PPO_CF_WANDB_PROJECT" ;;
  phase4a) exec python -m manual_steering.two_phase phase4a --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 24 --pre-phases 0.30 0.50 0.75 1.00 --seeds 0 1 2 --betas 0.25 0.75 1.5 3.0 5.0 --steps 200000 --project "$PPO_CF_WANDB_PROJECT" ;;
  phase4b) exec python -m manual_steering.two_phase phase4b --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 8 --kappas 0.0 0.3 0.6 0.9 --seeds 0 1 2 --treatment-beta 3.0 --steps 500000 --project "$PPO_CF_WANDB_PROJECT" ;;
  phase5) exec python -m manual_steering.two_phase phase5 --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 6 --seeds 0 1 2 --betas 0.25 0.75 1.5 3.0 5.0 --kappa 0.9 --steps 500000 --project "$PPO_CF_WANDB_PROJECT" ;;
  phase5b) exec python -m manual_steering.two_phase phase5b --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 8 --seeds 0 1 2 --bonus-ratios 0.25 0.75 1.5 3.0 5.0 7.0 13.0 --kappa 0.9 --steps 500000 --project "$PPO_CF_WANDB_PROJECT" ;;
  phase5c) exec python -m manual_steering.two_phase phase5c --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 8 --seeds 0 1 2 --bonus-ratios 0.25 0.75 1.5 3.0 5.0 7.0 13.0 --kappa 0.9 --layout-seed 0 --steps 500000 --project "$PPO_CF_WANDB_PROJECT" ;;
  phase5d) exec python -m manual_steering.two_phase phase5d --output "$MANUAL_OUTPUT" --chunk-index "${SLURM_ARRAY_TASK_ID:?}" --n-chunks 16 --seeds 0 1 2 --reward-lambdas 0.2 0.5 1.0 3.0 --perturb-betas 0.5 2.0 6.0 10.0 --kappa 0.9 --fixed-layout-seed 0 --steps 1000000 --project "$PPO_CF_WANDB_PROJECT" ;;
  *) echo "unknown manual-secondary worker role: $1" >&2; exit 2 ;;
esac
