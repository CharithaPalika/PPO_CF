#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_two_phase_v1}"
export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
array_job=$(sbatch --parsable --export=ALL --array=0-9%10 --job-name=manual_p1_tune --output=logs/manual_p1_%A_%a.out --error=logs/manual_p1_%A_%a.err --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long --wrap='exec bash slurm/manual_secondary_worker.sh tune')
selector_job=$(sbatch --parsable --export=ALL --dependency=afterok:${array_job} --job-name=manual_p1_select --output=logs/manual_p1_select_%j.out --error=logs/manual_p1_select_%j.err --time=00:20:00 --cpus-per-task=1 --mem=2G --partition=normal --wrap='exec bash slurm/manual_secondary_worker.sh select')
echo "Phase 1 submitted: tuning array=$array_job (10 tasks, max 10 active); selector=$selector_job"
echo "When selector finishes, run: ./submit_manual_secondary_phase2.sh"
