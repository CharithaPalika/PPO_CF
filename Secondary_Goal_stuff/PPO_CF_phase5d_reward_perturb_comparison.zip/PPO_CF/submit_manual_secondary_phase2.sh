#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_two_phase_v1}"
[ -f "$OUTPUT/best_ppo_params.json" ] || { echo "Missing $OUTPUT/best_ppo_params.json. Wait for phase-1 selector." >&2; exit 1; }
export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
job=$(sbatch --parsable --export=ALL --array=0-9%10 --job-name=manual_p2 --output=logs/manual_p2_%A_%a.out --error=logs/manual_p2_%A_%a.err --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long --wrap='exec bash slurm/manual_secondary_worker.sh phase2')
echo "Phase 2 submitted: array=$job; 10 chunks x 2 runs = 20 runs; max 10 active."
echo "After completion: python -m manual_steering.experiment --phase plot --output $OUTPUT/analysis"
