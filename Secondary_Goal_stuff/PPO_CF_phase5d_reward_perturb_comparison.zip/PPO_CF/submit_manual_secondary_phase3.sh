#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_phase3_v1}"
[ -f "$OUTPUT/best_ppo_params.json" ] || { echo "Missing $OUTPUT/best_ppo_params.json. Finish phase 1 first." >&2; exit 1; }

# Fails before submission unless the selected ckpt_100.pt exists.  It also
# freezes the exact source checkpoint, 200k budget, control, and five betas.
python -m manual_steering.two_phase phase3-manifest --output "$OUTPUT" \
  --seeds 0 1 2 3 4 --betas 0.25 0.75 1.5 3.0 5.0 --steps 200000

export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
job=$(sbatch --parsable --export=ALL --array=0-14%10 --job-name=manual_p3 \
  --output=logs/manual_p3_%A_%a.out --error=logs/manual_p3_%A_%a.err \
  --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long \
  --wrap='exec bash slurm/manual_secondary_worker.sh phase3')
echo "Phase 3 submitted: array=$job; 15 chunks x 2 runs = 30 runs; max 10 active."
echo "All arms load the selected phase-1 ckpt_100.pt; manual steering is active only before blue collection."
echo "After completion: python -m manual_steering.experiment --phase plot --output $OUTPUT/phase3"
