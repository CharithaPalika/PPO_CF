#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_phase4a_v1}"
[ -f "$OUTPUT/best_ppo_params.json" ] || { echo "Missing $OUTPUT/best_ppo_params.json. Finish phase 1 first." >&2; exit 1; }

# This is the only manifest write.  Array workers only read it, so parallel
# workers cannot race through one shared *.tmp path.
python -m manual_steering.two_phase phase4a-manifest --output "$OUTPUT" \
  --pre-phases 0.30 0.50 0.75 1.00 --seeds 0 1 2 \
  --betas 0.25 0.75 1.5 3.0 5.0 --steps 200000

export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
job=$(sbatch --parsable --export=ALL --array=0-23%16 --job-name=manual_p4a \
  --output=logs/manual_p4a_%A_%a.out --error=logs/manual_p4a_%A_%a.err \
  --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long \
  --wrap='exec bash slurm/manual_secondary_worker.sh phase4a')
echo "Phase 4a submitted: array=$job; 24 chunks x 3 runs = 72 runs; max 16 active."
echo "Grid: checkpoint {30,50,75,100}% x beta {0,0.25,0.75,1.5,3,5} x seeds {0,1,2}; 200k steps per arm."
echo "W&B config contains manual.phase=4a and manual.checkpoint_fraction; tags contain phase-4a and checkpoint-XXX."
