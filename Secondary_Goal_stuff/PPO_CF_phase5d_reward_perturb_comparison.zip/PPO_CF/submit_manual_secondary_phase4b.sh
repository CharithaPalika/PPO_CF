#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_phase4b_v1}"
# One deliberate experimental knob: kappa. Every arm starts from scratch;
# beta=3 is compared with its matched beta=0 fresh-training control.
python -m manual_steering.two_phase phase4b-manifest --output "$OUTPUT" \
  --kappas 0.0 0.3 0.6 0.9 --seeds 0 1 2 --treatment-beta 3.0 --steps 500000

export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
job=$(sbatch --parsable --export=ALL --array=0-7%8 --job-name=manual_p4b \
  --output=logs/manual_p4b_%A_%a.out --error=logs/manual_p4b_%A_%a.err \
  --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long \
  --wrap='exec bash slurm/manual_secondary_worker.sh phase4b')
echo "Phase 4b submitted: array=$job; 8 chunks x 3 runs = 24 runs; max 8 active."
echo "Sweep: kappa {0,0.3,0.6,0.9}; each has fresh beta {0,3} arms and seeds {0,1,2}."
echo "W&B: manual.phase=4b; tags include phase-4b, fresh-init, and kappa-0p0/0p3/0p6/0p9."
