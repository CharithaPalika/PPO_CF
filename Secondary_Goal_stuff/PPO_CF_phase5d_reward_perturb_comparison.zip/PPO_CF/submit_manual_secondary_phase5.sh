#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_phase5_v1}"

python -m manual_steering.two_phase phase5-manifest --output "$OUTPUT" \
  --seeds 0 1 2 --betas 0.25 0.75 1.5 3.0 5.0 --kappa 0.9 --steps 500000

export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
job=$(sbatch --parsable --export=ALL --array=0-5%6 --job-name=manual_p5 \
  --output=logs/manual_p5_%A_%a.out --error=logs/manual_p5_%A_%a.err \
  --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long \
  --wrap='exec bash slurm/manual_secondary_worker.sh phase5')
echo "Phase 5 submitted: array=$job; 6 chunks x 3 runs = 18 fresh runs; max 6 active."
echo "Sweep: beta {0,0.25,0.75,1.5,3,5}; seeds {0,1,2}; fixed per-step kappa=0.9."
echo "W&B: filter/group by config manual.phase=5 and manual.beta; tags include phase-5, two-route, beta-*, and kappa-0.9."
