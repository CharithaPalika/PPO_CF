#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_phase5b_v1}"

python -m manual_steering.two_phase phase5b-manifest --output "$OUTPUT" \
  --seeds 0 1 2 --bonus-ratios 0.25 0.75 1.5 3.0 5.0 7.0 13.0 --kappa 0.9 --steps 500000

export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
job=$(sbatch --parsable --export=ALL --array=0-7%8 --job-name=manual_p5b \
  --output=logs/manual_p5b_%A_%a.out --error=logs/manual_p5b_%A_%a.err \
  --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long \
  --wrap='exec bash slurm/manual_secondary_worker.sh phase5b')
echo "Phase 5b submitted: array=$job; 8 chunks x 3 runs = 24 fresh runs; max 8 active."
echo "Sweep: token-bonus ratio {0,0.25,0.75,1.5,3,5,7,13}; seeds {0,1,2}; fixed kappa=0.9."
echo "W&B: filter/group by manual.phase=5b and reward.token_bonus_ratio (or secondary.weight)."
