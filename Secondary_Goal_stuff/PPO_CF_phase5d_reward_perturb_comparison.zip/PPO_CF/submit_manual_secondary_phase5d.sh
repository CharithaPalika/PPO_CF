#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs runs artifacts/wandb
command -v sbatch >/dev/null || { echo "sbatch not found; run this on xlogin." >&2; exit 1; }
OUTPUT="${MANUAL_OUTPUT:-runs/manual_secondary_two_phase}"
PROJECT="${PPO_CF_WANDB_PROJECT:-ppo-manual-secondary-goal}"
NAMESPACE="${PPO_CF_WANDB_RUN_NAMESPACE:-manual_secondary_phase5d_v1}"

python -m manual_steering.two_phase phase5d-manifest --output "$OUTPUT" \
  --seeds 0 1 2 --reward-lambdas 0.2 0.5 1.0 3.0 --perturb-betas 0.5 2.0 6.0 10.0 \
  --kappa 0.9 --fixed-layout-seed 0 --steps 1000000

export MANUAL_OUTPUT="$OUTPUT" PPO_CF_WANDB_PROJECT="$PROJECT"
export PPO_CF_WANDB_RUN_NAMESPACE="$NAMESPACE" PPO_CF_WANDB=1 WANDB_MODE=online
job=$(sbatch --parsable --export=ALL --array=0-15%16 --job-name=manual_p5d \
  --output=logs/manual_p5d_%A_%a.out --error=logs/manual_p5d_%A_%a.err \
  --time=12:00:00 --cpus-per-task=4 --mem=8G --partition=long \
  --wrap='exec bash slurm/manual_secondary_worker.sh phase5d')
echo "Phase 5d submitted: 16 workers x 3 sequential runs = 48 fresh 1M-step runs; max 16 active."
echo "Factorial grid: layout {random,fixed} x method {reward,perturb} x 3 seeds x 4 method-specific scalers."
echo "W&B: group by manual.phase=5d, test.method, test.scaler, and env.layout_seeds; tags repeat every factor."
